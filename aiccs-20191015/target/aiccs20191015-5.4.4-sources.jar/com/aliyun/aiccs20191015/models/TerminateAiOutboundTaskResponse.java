// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.aiccs20191015.models;

import com.aliyun.tea.*;

public class TerminateAiOutboundTaskResponse extends TeaModel {
    @NameInMap("headers")
    public java.util.Map<String, String> headers;

    @NameInMap("statusCode")
    public Integer statusCode;

    @NameInMap("body")
    public TerminateAiOutboundTaskResponseBody body;

    public static TerminateAiOutboundTaskResponse build(java.util.Map<String, ?> map) throws Exception {
        TerminateAiOutboundTaskResponse self = new TerminateAiOutboundTaskResponse();
        return TeaModel.build(map, self);
    }

    public TerminateAiOutboundTaskResponse setHeaders(java.util.Map<String, String> headers) {
        this.headers = headers;
        return this;
    }
    public java.util.Map<String, String> getHeaders() {
        return this.headers;
    }

    public TerminateAiOutboundTaskResponse setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
        return this;
    }
    public Integer getStatusCode() {
        return this.statusCode;
    }

    public TerminateAiOutboundTaskResponse setBody(TerminateAiOutboundTaskResponseBody body) {
        this.body = body;
        return this;
    }
    public TerminateAiOutboundTaskResponseBody getBody() {
        return this.body;
    }

}
