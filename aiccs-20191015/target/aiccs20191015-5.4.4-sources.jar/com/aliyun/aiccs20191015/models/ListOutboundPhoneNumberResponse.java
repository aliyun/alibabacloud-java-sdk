// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.aiccs20191015.models;

import com.aliyun.tea.*;

public class ListOutboundPhoneNumberResponse extends TeaModel {
    @NameInMap("headers")
    public java.util.Map<String, String> headers;

    @NameInMap("statusCode")
    public Integer statusCode;

    @NameInMap("body")
    public ListOutboundPhoneNumberResponseBody body;

    public static ListOutboundPhoneNumberResponse build(java.util.Map<String, ?> map) throws Exception {
        ListOutboundPhoneNumberResponse self = new ListOutboundPhoneNumberResponse();
        return TeaModel.build(map, self);
    }

    public ListOutboundPhoneNumberResponse setHeaders(java.util.Map<String, String> headers) {
        this.headers = headers;
        return this;
    }
    public java.util.Map<String, String> getHeaders() {
        return this.headers;
    }

    public ListOutboundPhoneNumberResponse setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
        return this;
    }
    public Integer getStatusCode() {
        return this.statusCode;
    }

    public ListOutboundPhoneNumberResponse setBody(ListOutboundPhoneNumberResponseBody body) {
        this.body = body;
        return this;
    }
    public ListOutboundPhoneNumberResponseBody getBody() {
        return this.body;
    }

}
