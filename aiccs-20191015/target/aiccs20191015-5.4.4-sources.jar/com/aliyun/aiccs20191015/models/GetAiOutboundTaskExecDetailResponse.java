// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.aiccs20191015.models;

import com.aliyun.tea.*;

public class GetAiOutboundTaskExecDetailResponse extends TeaModel {
    @NameInMap("headers")
    public java.util.Map<String, String> headers;

    @NameInMap("statusCode")
    public Integer statusCode;

    @NameInMap("body")
    public GetAiOutboundTaskExecDetailResponseBody body;

    public static GetAiOutboundTaskExecDetailResponse build(java.util.Map<String, ?> map) throws Exception {
        GetAiOutboundTaskExecDetailResponse self = new GetAiOutboundTaskExecDetailResponse();
        return TeaModel.build(map, self);
    }

    public GetAiOutboundTaskExecDetailResponse setHeaders(java.util.Map<String, String> headers) {
        this.headers = headers;
        return this;
    }
    public java.util.Map<String, String> getHeaders() {
        return this.headers;
    }

    public GetAiOutboundTaskExecDetailResponse setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
        return this;
    }
    public Integer getStatusCode() {
        return this.statusCode;
    }

    public GetAiOutboundTaskExecDetailResponse setBody(GetAiOutboundTaskExecDetailResponseBody body) {
        this.body = body;
        return this;
    }
    public GetAiOutboundTaskExecDetailResponseBody getBody() {
        return this.body;
    }

}
