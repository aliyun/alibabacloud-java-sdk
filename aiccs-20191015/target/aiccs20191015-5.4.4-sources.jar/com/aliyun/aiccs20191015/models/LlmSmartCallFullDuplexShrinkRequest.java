// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.aiccs20191015.models;

import com.aliyun.tea.*;

public class LlmSmartCallFullDuplexShrinkRequest extends TeaModel {
    /**
     * <p><strong>ApplicationCode</strong><br>The application code.</p>
     * <p>This parameter is required.</p>
     * 
     * <strong>example:</strong>
     * <p>app123</p>
     */
    @NameInMap("ApplicationCode")
    public String applicationCode;

    /**
     * <p><strong>CalledNumber</strong><br>The called number that receives the intelligent outbound call.</p>
     * <p>This parameter is required.</p>
     * 
     * <strong>example:</strong>
     * <p>1234567890</p>
     */
    @NameInMap("CalledNumber")
    public String calledNumber;

    /**
     * <p><strong>CallerNumber</strong><br>The caller number.</p>
     * <p>This parameter is required.</p>
     * 
     * <strong>example:</strong>
     * <p>0987654321</p>
     */
    @NameInMap("CallerNumber")
    public String callerNumber;

    /**
     * <p><strong>OutId</strong><br>The external ID. The length is 1 to 15 bytes.</p>
     * 
     * <strong>example:</strong>
     * <p>out123</p>
     */
    @NameInMap("OutId")
    public String outId;

    /**
     * <p><strong>SessionTimeout</strong><br>The maximum call duration. The call is automatically hung up after a timeout. Unit: seconds. The maximum call duration is 3,600 seconds.</p>
     * 
     * <strong>example:</strong>
     * <p>120</p>
     */
    @NameInMap("SessionTimeout")
    public Integer sessionTimeout;

    /**
     * <p><strong>StartWordParam</strong><br>The opening remark variables. Format: JSON. The format is opening remark variable name + parameter, such as <code>{&quot;custom&quot;:&quot;XXX&quot;}</code>.</p>
     * 
     * <strong>example:</strong>
     * <p>{&quot;tailnumber&quot;:&quot;7898&quot;,&quot;platformOrder&quot;:&quot;&quot;,&quot;signatory&quot;:&quot;Customer&quot;}</p>
     */
    @NameInMap("StartWordParam")
    public String startWordParamShrink;

    /**
     * <p>The voice speed. Valid values: 0 to 100. If you do not specify this parameter, the value configured in the application is used.</p>
     * 
     * <strong>example:</strong>
     * <p>70</p>
     */
    @NameInMap("TtsSpeed")
    public Integer ttsSpeed;

    /**
     * <p>The voice code for the personalized voice. If you do not specify this parameter, the value configured in the application is used.</p>
     * 
     * <strong>example:</strong>
     * <p>V745A7CED</p>
     */
    @NameInMap("TtsVoiceCode")
    public String ttsVoiceCode;

    /**
     * <p>The volume. Valid values: -200 to 200. If you do not specify this parameter, the value configured in the application is used.</p>
     * 
     * <strong>example:</strong>
     * <p>100</p>
     */
    @NameInMap("TtsVolume")
    public Integer ttsVolume;

    public static LlmSmartCallFullDuplexShrinkRequest build(java.util.Map<String, ?> map) throws Exception {
        LlmSmartCallFullDuplexShrinkRequest self = new LlmSmartCallFullDuplexShrinkRequest();
        return TeaModel.build(map, self);
    }

    public LlmSmartCallFullDuplexShrinkRequest setApplicationCode(String applicationCode) {
        this.applicationCode = applicationCode;
        return this;
    }
    public String getApplicationCode() {
        return this.applicationCode;
    }

    public LlmSmartCallFullDuplexShrinkRequest setCalledNumber(String calledNumber) {
        this.calledNumber = calledNumber;
        return this;
    }
    public String getCalledNumber() {
        return this.calledNumber;
    }

    public LlmSmartCallFullDuplexShrinkRequest setCallerNumber(String callerNumber) {
        this.callerNumber = callerNumber;
        return this;
    }
    public String getCallerNumber() {
        return this.callerNumber;
    }

    public LlmSmartCallFullDuplexShrinkRequest setOutId(String outId) {
        this.outId = outId;
        return this;
    }
    public String getOutId() {
        return this.outId;
    }

    public LlmSmartCallFullDuplexShrinkRequest setSessionTimeout(Integer sessionTimeout) {
        this.sessionTimeout = sessionTimeout;
        return this;
    }
    public Integer getSessionTimeout() {
        return this.sessionTimeout;
    }

    public LlmSmartCallFullDuplexShrinkRequest setStartWordParamShrink(String startWordParamShrink) {
        this.startWordParamShrink = startWordParamShrink;
        return this;
    }
    public String getStartWordParamShrink() {
        return this.startWordParamShrink;
    }

    public LlmSmartCallFullDuplexShrinkRequest setTtsSpeed(Integer ttsSpeed) {
        this.ttsSpeed = ttsSpeed;
        return this;
    }
    public Integer getTtsSpeed() {
        return this.ttsSpeed;
    }

    public LlmSmartCallFullDuplexShrinkRequest setTtsVoiceCode(String ttsVoiceCode) {
        this.ttsVoiceCode = ttsVoiceCode;
        return this;
    }
    public String getTtsVoiceCode() {
        return this.ttsVoiceCode;
    }

    public LlmSmartCallFullDuplexShrinkRequest setTtsVolume(Integer ttsVolume) {
        this.ttsVolume = ttsVolume;
        return this;
    }
    public Integer getTtsVolume() {
        return this.ttsVolume;
    }

}
