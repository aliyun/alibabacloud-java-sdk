// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.aiccs20191015.models;

import com.aliyun.tea.*;

public class UpdateAiCallTaskRequest extends TeaModel {
    /**
     * <p>The allowed call days.</p>
     * <p>This parameter is required.</p>
     */
    @NameInMap("CallDay")
    public java.util.List<String> callDay;

    /**
     * <p>The expiration date for outbound call details, which specifies the exact end time. Format: YYYY-MM-DD HH:mm:ss.</p>
     * 
     * <strong>example:</strong>
     * <p>2026-07-30 20:00:20</p>
     */
    @NameInMap("CallExpireDate")
    public String callExpireDate;

    /**
     * <p>The expiration duration for outbound call details. Unit: minutes.</p>
     * 
     * <strong>example:</strong>
     * <p>10</p>
     */
    @NameInMap("CallExpireMinutes")
    public Long callExpireMinutes;

    /**
     * <p>The validity period type for outbound calls. Valid values:</p>
     * <p>0: long-term validity</p>
     * <p>1: valid for a specified period after import</p>
     * <p>2: valid until a specified time</p>
     * 
     * <strong>example:</strong>
     * <p>0</p>
     */
    @NameInMap("CallExpireType")
    public Long callExpireType;

    /**
     * <p>The retry interval. Unit: minutes. The maximum value is 120.</p>
     * 
     * <strong>example:</strong>
     * <p>25</p>
     */
    @NameInMap("CallRetryInterval")
    public Long callRetryInterval;

    /**
     * <p>The reasons for retrying failed calls.</p>
     */
    @NameInMap("CallRetryReason")
    public java.util.List<String> callRetryReason;

    /**
     * <p>The number of retries. The maximum value is 3.</p>
     * 
     * <strong>example:</strong>
     * <p>2</p>
     */
    @NameInMap("CallRetryTimes")
    public Long callRetryTimes;

    /**
     * <p>The allowed call time.</p>
     * <p>This parameter is required.</p>
     */
    @NameInMap("CallTime")
    public java.util.List<String> callTime;

    /**
     * <p>The list of allowed call time periods. Each element is represented as a JSON string that contains startTime and endTime.</p>
     */
    @NameInMap("CallableTime")
    public java.util.List<String> callableTime;

    /**
     * <p>The line encoding.</p>
     * 
     * <strong>example:</strong>
     * <p>JILIANG_***_***_NET</p>
     */
    @NameInMap("LineEncoding")
    public String lineEncoding;

    /**
     * <p>The number of the customer-provided line.</p>
     * 
     * <strong>example:</strong>
     * <p>152****3120</p>
     */
    @NameInMap("LinePhoneNum")
    public String linePhoneNum;

    /**
     * <p>Specifies whether to enable retry. Valid values:</p>
     * <ul>
     * <li><p>true: enabled.</p>
     * </li>
     * <li><p>false (default): disabled.</p>
     * </li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>true</p>
     */
    @NameInMap("MissCallRetry")
    public Boolean missCallRetry;

    @NameInMap("OwnerId")
    public Long ownerId;

    /**
     * <p>The number type. This parameter is used when the creation source is engine creation. Valid values:</p>
     * <p>0: Alibaba Cloud number</p>
     * <p>1: customer-provided line</p>
     * 
     * <strong>example:</strong>
     * <p>0</p>
     */
    @NameInMap("PhoneType")
    public Long phoneType;

    @NameInMap("ResourceOwnerAccount")
    public String resourceOwnerAccount;

    @NameInMap("ResourceOwnerId")
    public Long resourceOwnerId;

    /**
     * <p>The creation source. Valid values:</p>
     * <p>0: created by an agent</p>
     * <p>1: created by an engine</p>
     * 
     * <strong>example:</strong>
     * <p>Cannot be modified. Leave this parameter empty</p>
     */
    @NameInMap("Source")
    public Long source;

    /**
     * <p>The start mode. Valid values:</p>
     * <ul>
     * <li><p>IMMEDIATE: immediate start.</p>
     * </li>
     * <li><p>SCHEDULE: scheduled start.</p>
     * </li>
     * </ul>
     * <p>This parameter is required.</p>
     * 
     * <strong>example:</strong>
     * <p>IMMEDIATE</p>
     */
    @NameInMap("StartType")
    public String startType;

    /**
     * <p>The task concurrency. The maximum value is 500.</p>
     * <p>This parameter is required.</p>
     * 
     * <strong>example:</strong>
     * <p>57</p>
     */
    @NameInMap("TaskCps")
    public Long taskCps;

    /**
     * <p>The ID of the task to be updated.</p>
     * <p>This parameter is required.</p>
     * 
     * <strong>example:</strong>
     * <p>1187**************</p>
     */
    @NameInMap("TaskId")
    public String taskId;

    /**
     * <p>The name of the task. The name must be unique within the same account.</p>
     * <p>This parameter is required.</p>
     * 
     * <strong>example:</strong>
     * <p>TestTask</p>
     */
    @NameInMap("TaskName")
    public String taskName;

    /**
     * <p>The preset start time of the task. The value is a timestamp in milliseconds. This parameter is valid and required only when the StartType parameter is set to SCHEDULE. The task automatically starts at the specified time.</p>
     * 
     * <strong>example:</strong>
     * <p>1748923429000</p>
     */
    @NameInMap("TaskStartTime")
    public Long taskStartTime;

    /**
     * <p>The service instance used for outbound calls.</p>
     * 
     * <strong>example:</strong>
     * <p>0537022*****</p>
     */
    @NameInMap("VirtualNumber")
    public String virtualNumber;

    public static UpdateAiCallTaskRequest build(java.util.Map<String, ?> map) throws Exception {
        UpdateAiCallTaskRequest self = new UpdateAiCallTaskRequest();
        return TeaModel.build(map, self);
    }

    public UpdateAiCallTaskRequest setCallDay(java.util.List<String> callDay) {
        this.callDay = callDay;
        return this;
    }
    public java.util.List<String> getCallDay() {
        return this.callDay;
    }

    public UpdateAiCallTaskRequest setCallExpireDate(String callExpireDate) {
        this.callExpireDate = callExpireDate;
        return this;
    }
    public String getCallExpireDate() {
        return this.callExpireDate;
    }

    public UpdateAiCallTaskRequest setCallExpireMinutes(Long callExpireMinutes) {
        this.callExpireMinutes = callExpireMinutes;
        return this;
    }
    public Long getCallExpireMinutes() {
        return this.callExpireMinutes;
    }

    public UpdateAiCallTaskRequest setCallExpireType(Long callExpireType) {
        this.callExpireType = callExpireType;
        return this;
    }
    public Long getCallExpireType() {
        return this.callExpireType;
    }

    public UpdateAiCallTaskRequest setCallRetryInterval(Long callRetryInterval) {
        this.callRetryInterval = callRetryInterval;
        return this;
    }
    public Long getCallRetryInterval() {
        return this.callRetryInterval;
    }

    public UpdateAiCallTaskRequest setCallRetryReason(java.util.List<String> callRetryReason) {
        this.callRetryReason = callRetryReason;
        return this;
    }
    public java.util.List<String> getCallRetryReason() {
        return this.callRetryReason;
    }

    public UpdateAiCallTaskRequest setCallRetryTimes(Long callRetryTimes) {
        this.callRetryTimes = callRetryTimes;
        return this;
    }
    public Long getCallRetryTimes() {
        return this.callRetryTimes;
    }

    public UpdateAiCallTaskRequest setCallTime(java.util.List<String> callTime) {
        this.callTime = callTime;
        return this;
    }
    public java.util.List<String> getCallTime() {
        return this.callTime;
    }

    public UpdateAiCallTaskRequest setCallableTime(java.util.List<String> callableTime) {
        this.callableTime = callableTime;
        return this;
    }
    public java.util.List<String> getCallableTime() {
        return this.callableTime;
    }

    public UpdateAiCallTaskRequest setLineEncoding(String lineEncoding) {
        this.lineEncoding = lineEncoding;
        return this;
    }
    public String getLineEncoding() {
        return this.lineEncoding;
    }

    public UpdateAiCallTaskRequest setLinePhoneNum(String linePhoneNum) {
        this.linePhoneNum = linePhoneNum;
        return this;
    }
    public String getLinePhoneNum() {
        return this.linePhoneNum;
    }

    public UpdateAiCallTaskRequest setMissCallRetry(Boolean missCallRetry) {
        this.missCallRetry = missCallRetry;
        return this;
    }
    public Boolean getMissCallRetry() {
        return this.missCallRetry;
    }

    public UpdateAiCallTaskRequest setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
        return this;
    }
    public Long getOwnerId() {
        return this.ownerId;
    }

    public UpdateAiCallTaskRequest setPhoneType(Long phoneType) {
        this.phoneType = phoneType;
        return this;
    }
    public Long getPhoneType() {
        return this.phoneType;
    }

    public UpdateAiCallTaskRequest setResourceOwnerAccount(String resourceOwnerAccount) {
        this.resourceOwnerAccount = resourceOwnerAccount;
        return this;
    }
    public String getResourceOwnerAccount() {
        return this.resourceOwnerAccount;
    }

    public UpdateAiCallTaskRequest setResourceOwnerId(Long resourceOwnerId) {
        this.resourceOwnerId = resourceOwnerId;
        return this;
    }
    public Long getResourceOwnerId() {
        return this.resourceOwnerId;
    }

    public UpdateAiCallTaskRequest setSource(Long source) {
        this.source = source;
        return this;
    }
    public Long getSource() {
        return this.source;
    }

    public UpdateAiCallTaskRequest setStartType(String startType) {
        this.startType = startType;
        return this;
    }
    public String getStartType() {
        return this.startType;
    }

    public UpdateAiCallTaskRequest setTaskCps(Long taskCps) {
        this.taskCps = taskCps;
        return this;
    }
    public Long getTaskCps() {
        return this.taskCps;
    }

    public UpdateAiCallTaskRequest setTaskId(String taskId) {
        this.taskId = taskId;
        return this;
    }
    public String getTaskId() {
        return this.taskId;
    }

    public UpdateAiCallTaskRequest setTaskName(String taskName) {
        this.taskName = taskName;
        return this;
    }
    public String getTaskName() {
        return this.taskName;
    }

    public UpdateAiCallTaskRequest setTaskStartTime(Long taskStartTime) {
        this.taskStartTime = taskStartTime;
        return this;
    }
    public Long getTaskStartTime() {
        return this.taskStartTime;
    }

    public UpdateAiCallTaskRequest setVirtualNumber(String virtualNumber) {
        this.virtualNumber = virtualNumber;
        return this;
    }
    public String getVirtualNumber() {
        return this.virtualNumber;
    }

}
