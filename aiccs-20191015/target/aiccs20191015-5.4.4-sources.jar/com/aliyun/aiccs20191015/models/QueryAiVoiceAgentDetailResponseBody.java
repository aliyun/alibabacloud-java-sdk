// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.aiccs20191015.models;

import com.aliyun.tea.*;

public class QueryAiVoiceAgentDetailResponseBody extends TeaModel {
    /**
     * <p>The detailed reason for the access denial.</p>
     * 
     * <strong>example:</strong>
     * <p>None</p>
     */
    @NameInMap("AccessDeniedDetail")
    public String accessDeniedDetail;

    /**
     * <p>The status code.</p>
     * 
     * <strong>example:</strong>
     * <p>OK</p>
     */
    @NameInMap("Code")
    public String code;

    /**
     * <p>The agent details data.</p>
     */
    @NameInMap("Data")
    public QueryAiVoiceAgentDetailResponseBodyData data;

    /**
     * <p>The status code description.</p>
     * 
     * <strong>example:</strong>
     * <p>Success</p>
     */
    @NameInMap("Message")
    public String message;

    /**
     * <p>The request ID.</p>
     * 
     * <strong>example:</strong>
     * <p>742C9243-2870-B8D6-0C68-C60BEB2DF09A</p>
     */
    @NameInMap("RequestId")
    public String requestId;

    /**
     * <p>Indicates whether the API call is successful. Valid values:</p>
     * <ul>
     * <li><strong>true</strong>: Success.</li>
     * <li><strong>false</strong>: Failure.</li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>false</p>
     */
    @NameInMap("Success")
    public Boolean success;

    public static QueryAiVoiceAgentDetailResponseBody build(java.util.Map<String, ?> map) throws Exception {
        QueryAiVoiceAgentDetailResponseBody self = new QueryAiVoiceAgentDetailResponseBody();
        return TeaModel.build(map, self);
    }

    public QueryAiVoiceAgentDetailResponseBody setAccessDeniedDetail(String accessDeniedDetail) {
        this.accessDeniedDetail = accessDeniedDetail;
        return this;
    }
    public String getAccessDeniedDetail() {
        return this.accessDeniedDetail;
    }

    public QueryAiVoiceAgentDetailResponseBody setCode(String code) {
        this.code = code;
        return this;
    }
    public String getCode() {
        return this.code;
    }

    public QueryAiVoiceAgentDetailResponseBody setData(QueryAiVoiceAgentDetailResponseBodyData data) {
        this.data = data;
        return this;
    }
    public QueryAiVoiceAgentDetailResponseBodyData getData() {
        return this.data;
    }

    public QueryAiVoiceAgentDetailResponseBody setMessage(String message) {
        this.message = message;
        return this;
    }
    public String getMessage() {
        return this.message;
    }

    public QueryAiVoiceAgentDetailResponseBody setRequestId(String requestId) {
        this.requestId = requestId;
        return this;
    }
    public String getRequestId() {
        return this.requestId;
    }

    public QueryAiVoiceAgentDetailResponseBody setSuccess(Boolean success) {
        this.success = success;
        return this;
    }
    public Boolean getSuccess() {
        return this.success;
    }

    public static class QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigEventConfig extends TeaModel {
        /**
         * <p>Specifies whether to hang up when an AI call assistant is detected.</p>
         * 
         * <strong>example:</strong>
         * <p>false</p>
         */
        @NameInMap("CallAssistantHangup")
        public Boolean callAssistantHangup;

        /**
         * <p>Specifies whether to enable the recognition of AI call assistants.</p>
         * 
         * <strong>example:</strong>
         * <p>true</p>
         */
        @NameInMap("CallAssistantRecognize")
        public Boolean callAssistantRecognize;

        /**
         * <p>Specifies whether the first silence invokes the model.</p>
         * 
         * <strong>example:</strong>
         * <p>false</p>
         */
        @NameInMap("MuteActive")
        public Boolean muteActive;

        /**
         * <p>The silence duration.</p>
         * <blockquote>
         * <ul>
         * <li>Maximum value: 15.</li>
         * <li>Minimum value: 3.</li>
         * </ul>
         * </blockquote>
         * 
         * <strong>example:</strong>
         * <p>10</p>
         */
        @NameInMap("MuteDuration")
        public Long muteDuration;

        /**
         * <p>The number of consecutive silence events after which the call is actively disconnected.</p>
         * <blockquote>
         * <ul>
         * <li>Maximum value: 5.</li>
         * <li>Minimum value: 1.</li>
         * </ul>
         * </blockquote>
         * 
         * <strong>example:</strong>
         * <p>1</p>
         */
        @NameInMap("MuteHangupNum")
        public Long muteHangupNum;

        /**
         * <p>The maximum call duration. The call is automatically disconnected after a timeout. Unit: seconds.</p>
         * <blockquote>
         * <ul>
         * <li>Maximum value: 3600.</li>
         * <li>Minimum value: 600.</li>
         * </ul>
         * </blockquote>
         * 
         * <strong>example:</strong>
         * <p>600</p>
         */
        @NameInMap("SessionTimeout")
        public Long sessionTimeout;

        public static QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigEventConfig build(java.util.Map<String, ?> map) throws Exception {
            QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigEventConfig self = new QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigEventConfig();
            return TeaModel.build(map, self);
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigEventConfig setCallAssistantHangup(Boolean callAssistantHangup) {
            this.callAssistantHangup = callAssistantHangup;
            return this;
        }
        public Boolean getCallAssistantHangup() {
            return this.callAssistantHangup;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigEventConfig setCallAssistantRecognize(Boolean callAssistantRecognize) {
            this.callAssistantRecognize = callAssistantRecognize;
            return this;
        }
        public Boolean getCallAssistantRecognize() {
            return this.callAssistantRecognize;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigEventConfig setMuteActive(Boolean muteActive) {
            this.muteActive = muteActive;
            return this;
        }
        public Boolean getMuteActive() {
            return this.muteActive;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigEventConfig setMuteDuration(Long muteDuration) {
            this.muteDuration = muteDuration;
            return this;
        }
        public Long getMuteDuration() {
            return this.muteDuration;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigEventConfig setMuteHangupNum(Long muteHangupNum) {
            this.muteHangupNum = muteHangupNum;
            return this;
        }
        public Long getMuteHangupNum() {
            return this.muteHangupNum;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigEventConfig setSessionTimeout(Long sessionTimeout) {
            this.sessionTimeout = sessionTimeout;
            return this;
        }
        public Long getSessionTimeout() {
            return this.sessionTimeout;
        }

    }

    public static class QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig extends TeaModel {
        /**
         * <p>Specifies whether to enable background sound.</p>
         * 
         * <strong>example:</strong>
         * <p>true</p>
         */
        @NameInMap("BackgroundEnabled")
        public Boolean backgroundEnabled;

        /**
         * <p>The background sound ID.</p>
         * 
         * <strong>example:</strong>
         * <p>1</p>
         */
        @NameInMap("BackgroundSound")
        public Long backgroundSound;

        /**
         * <p>The background sound volume. Valid values: 0 (low), 1 (medium), and 2 (high).</p>
         * 
         * <strong>example:</strong>
         * <p>1</p>
         */
        @NameInMap("BackgroundVolume")
        public Long backgroundVolume;

        /**
         * <p>Specifies whether to enable audio mixing.</p>
         * 
         * <strong>example:</strong>
         * <p>true</p>
         */
        @NameInMap("MixingEnabled")
        public Boolean mixingEnabled;

        /**
         * <p>The mixing template ID.</p>
         * 
         * <strong>example:</strong>
         * <p>1</p>
         */
        @NameInMap("MixingTemplate")
        public Long mixingTemplate;

        /**
         * <p>The TTS playback speed.</p>
         * <blockquote>
         * <ul>
         * <li>Valid values: -200 to 200. Default value: 0.</li>
         * <li>If you do not specify a value, the voice speed configured in the large model application is used by default.</li>
         * </ul>
         * </blockquote>
         * 
         * <strong>example:</strong>
         * <p>34</p>
         */
        @NameInMap("TtsSpeed")
        public Long ttsSpeed;

        /**
         * <p>The voice style.</p>
         * 
         * <strong>example:</strong>
         * <p>longxiaoxia_v2p1</p>
         */
        @NameInMap("TtsStyle")
        public String ttsStyle;

        /**
         * <p>The TTS playback volume.</p>
         * <blockquote>
         * <ul>
         * <li>Valid values: 0 to 100. Default value: 0.</li>
         * <li>If you do not specify a value, the volume configured in the large model application is used by default.</li>
         * </ul>
         * </blockquote>
         * 
         * <strong>example:</strong>
         * <p>72</p>
         */
        @NameInMap("TtsVolume")
        public Long ttsVolume;

        /**
         * <p>The voice code.</p>
         * 
         * <strong>example:</strong>
         * <p>Sample value</p>
         */
        @NameInMap("VoiceCode")
        public String voiceCode;

        /**
         * <p>The voice type. Valid values: SYSTEM (system voice), COSYCLONE (cloned voice), and BL-CUSTOM (custom premium cloned voice).</p>
         * 
         * <strong>example:</strong>
         * <p>Sample value</p>
         */
        @NameInMap("VoiceType")
        public String voiceType;

        public static QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig build(java.util.Map<String, ?> map) throws Exception {
            QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig self = new QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig();
            return TeaModel.build(map, self);
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig setBackgroundEnabled(Boolean backgroundEnabled) {
            this.backgroundEnabled = backgroundEnabled;
            return this;
        }
        public Boolean getBackgroundEnabled() {
            return this.backgroundEnabled;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig setBackgroundSound(Long backgroundSound) {
            this.backgroundSound = backgroundSound;
            return this;
        }
        public Long getBackgroundSound() {
            return this.backgroundSound;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig setBackgroundVolume(Long backgroundVolume) {
            this.backgroundVolume = backgroundVolume;
            return this;
        }
        public Long getBackgroundVolume() {
            return this.backgroundVolume;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig setMixingEnabled(Boolean mixingEnabled) {
            this.mixingEnabled = mixingEnabled;
            return this;
        }
        public Boolean getMixingEnabled() {
            return this.mixingEnabled;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig setMixingTemplate(Long mixingTemplate) {
            this.mixingTemplate = mixingTemplate;
            return this;
        }
        public Long getMixingTemplate() {
            return this.mixingTemplate;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig setTtsSpeed(Long ttsSpeed) {
            this.ttsSpeed = ttsSpeed;
            return this;
        }
        public Long getTtsSpeed() {
            return this.ttsSpeed;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig setTtsStyle(String ttsStyle) {
            this.ttsStyle = ttsStyle;
            return this;
        }
        public String getTtsStyle() {
            return this.ttsStyle;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig setTtsVolume(Long ttsVolume) {
            this.ttsVolume = ttsVolume;
            return this;
        }
        public Long getTtsVolume() {
            return this.ttsVolume;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig setVoiceCode(String voiceCode) {
            this.voiceCode = voiceCode;
            return this;
        }
        public String getVoiceCode() {
            return this.voiceCode;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig setVoiceType(String voiceType) {
            this.voiceType = voiceType;
            return this;
        }
        public String getVoiceType() {
            return this.voiceType;
        }

    }

    public static class QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfig extends TeaModel {
        /**
         * <p>The call event configuration.</p>
         */
        @NameInMap("EventConfig")
        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigEventConfig eventConfig;

        /**
         * <p>The TTS configuration.</p>
         */
        @NameInMap("TtsConfig")
        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig ttsConfig;

        /**
         * <p>The hot word ID.</p>
         * 
         * <strong>example:</strong>
         * <p>afb2c43**********83e6df30551c11f7</p>
         */
        @NameInMap("VocabId")
        public String vocabId;

        public static QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfig build(java.util.Map<String, ?> map) throws Exception {
            QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfig self = new QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfig();
            return TeaModel.build(map, self);
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfig setEventConfig(QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigEventConfig eventConfig) {
            this.eventConfig = eventConfig;
            return this;
        }
        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigEventConfig getEventConfig() {
            return this.eventConfig;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfig setTtsConfig(QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig ttsConfig) {
            this.ttsConfig = ttsConfig;
            return this;
        }
        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfigTtsConfig getTtsConfig() {
            return this.ttsConfig;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfig setVocabId(String vocabId) {
            this.vocabId = vocabId;
            return this;
        }
        public String getVocabId() {
            return this.vocabId;
        }

    }

    public static class QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigChildTaskList extends TeaModel {
        /**
         * <p>The child task description.</p>
         * 
         * <strong>example:</strong>
         * <p>New user invitation: &quot;Hello, parent! I am Teacher Wang from *****. We currently have 100 trial spots for the ** course and would like to schedule a trial class for your child. When would be a convenient time for you?&quot;\</p>
         */
        @NameInMap("ChildTaskDescription")
        public String childTaskDescription;

        /**
         * <p>The child task name.</p>
         * 
         * <strong>example:</strong>
         * <p>Opening and invitation</p>
         */
        @NameInMap("ChildTaskName")
        public String childTaskName;

        /**
         * <p>The unique ID of the child task.</p>
         * 
         * <strong>example:</strong>
         * <p>280cd4bf-*******df472c</p>
         */
        @NameInMap("Id")
        public String id;

        public static QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigChildTaskList build(java.util.Map<String, ?> map) throws Exception {
            QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigChildTaskList self = new QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigChildTaskList();
            return TeaModel.build(map, self);
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigChildTaskList setChildTaskDescription(String childTaskDescription) {
            this.childTaskDescription = childTaskDescription;
            return this;
        }
        public String getChildTaskDescription() {
            return this.childTaskDescription;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigChildTaskList setChildTaskName(String childTaskName) {
            this.childTaskName = childTaskName;
            return this;
        }
        public String getChildTaskName() {
            return this.childTaskName;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigChildTaskList setId(String id) {
            this.id = id;
            return this;
        }
        public String getId() {
            return this.id;
        }

    }

    public static class QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigCustomExceptionList extends TeaModel {
        /**
         * <p>Specifies whether it is output as an exception tag.</p>
         * 
         * <strong>example:</strong>
         * <p>true</p>
         */
        @NameInMap("ExceptionSign")
        public Boolean exceptionSign;

        /**
         * <p>The exception type.</p>
         * 
         * <strong>example:</strong>
         * <ul>
         * <li></li>
         * </ul>
         */
        @NameInMap("ExceptionType")
        public String exceptionType;

        /**
         * <p>The reply content.</p>
         * 
         * <strong>example:</strong>
         * <ul>
         * <li></li>
         * </ul>
         */
        @NameInMap("Reply")
        public String reply;

        /**
         * <p>Specifies whether interruption is supported.</p>
         * 
         * <strong>example:</strong>
         * <p>false</p>
         */
        @NameInMap("SupportBreak")
        public Boolean supportBreak;

        public static QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigCustomExceptionList build(java.util.Map<String, ?> map) throws Exception {
            QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigCustomExceptionList self = new QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigCustomExceptionList();
            return TeaModel.build(map, self);
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigCustomExceptionList setExceptionSign(Boolean exceptionSign) {
            this.exceptionSign = exceptionSign;
            return this;
        }
        public Boolean getExceptionSign() {
            return this.exceptionSign;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigCustomExceptionList setExceptionType(String exceptionType) {
            this.exceptionType = exceptionType;
            return this;
        }
        public String getExceptionType() {
            return this.exceptionType;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigCustomExceptionList setReply(String reply) {
            this.reply = reply;
            return this;
        }
        public String getReply() {
            return this.reply;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigCustomExceptionList setSupportBreak(Boolean supportBreak) {
            this.supportBreak = supportBreak;
            return this;
        }
        public Boolean getSupportBreak() {
            return this.supportBreak;
        }

    }

    public static class QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurposeMainPurposeEnum extends TeaModel {
        /**
         * <p>The description of the valid value.</p>
         * 
         * <strong>example:</strong>
         * <p>Strong intention</p>
         */
        @NameInMap("Description")
        public String description;

        /**
         * <p>The unique ID of the valid value.</p>
         * 
         * <strong>example:</strong>
         * <p>d5606d80-7625-dcea-xxxx-17f66fbb564a</p>
         */
        @NameInMap("Id")
        public String id;

        /**
         * <p>The valid value.</p>
         * 
         * <strong>example:</strong>
         * <p>A</p>
         */
        @NameInMap("Value")
        public String value;

        public static QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurposeMainPurposeEnum build(java.util.Map<String, ?> map) throws Exception {
            QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurposeMainPurposeEnum self = new QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurposeMainPurposeEnum();
            return TeaModel.build(map, self);
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurposeMainPurposeEnum setDescription(String description) {
            this.description = description;
            return this;
        }
        public String getDescription() {
            return this.description;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurposeMainPurposeEnum setId(String id) {
            this.id = id;
            return this;
        }
        public String getId() {
            return this.id;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurposeMainPurposeEnum setValue(String value) {
            this.value = value;
            return this;
        }
        public String getValue() {
            return this.value;
        }

    }

    public static class QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurpose extends TeaModel {
        /**
         * <p>The main intent ID.</p>
         * 
         * <strong>example:</strong>
         * <p>1ee6e994-08e0-xxxx-f662-1659cc54d409</p>
         */
        @NameInMap("Id")
        public String id;

        /**
         * <p>The main intent description.</p>
         * 
         * <strong>example:</strong>
         * <p>Call performance rating: A, B, C, D (A is the best)</p>
         */
        @NameInMap("MainPurposeDescription")
        public String mainPurposeDescription;

        /**
         * <p>The list of valid values for the main intent.</p>
         */
        @NameInMap("MainPurposeEnum")
        public java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurposeMainPurposeEnum> mainPurposeEnum;

        /**
         * <p>The main intent name.</p>
         * 
         * <strong>example:</strong>
         * <p>Call performance rating</p>
         */
        @NameInMap("MainPurposeName")
        public String mainPurposeName;

        /**
         * <p>The value type of the main intent. Currently, only the ENUM type is supported.</p>
         * 
         * <strong>example:</strong>
         * <p>ENUM</p>
         */
        @NameInMap("MainPurposeType")
        public String mainPurposeType;

        public static QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurpose build(java.util.Map<String, ?> map) throws Exception {
            QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurpose self = new QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurpose();
            return TeaModel.build(map, self);
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurpose setId(String id) {
            this.id = id;
            return this;
        }
        public String getId() {
            return this.id;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurpose setMainPurposeDescription(String mainPurposeDescription) {
            this.mainPurposeDescription = mainPurposeDescription;
            return this;
        }
        public String getMainPurposeDescription() {
            return this.mainPurposeDescription;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurpose setMainPurposeEnum(java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurposeMainPurposeEnum> mainPurposeEnum) {
            this.mainPurposeEnum = mainPurposeEnum;
            return this;
        }
        public java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurposeMainPurposeEnum> getMainPurposeEnum() {
            return this.mainPurposeEnum;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurpose setMainPurposeName(String mainPurposeName) {
            this.mainPurposeName = mainPurposeName;
            return this;
        }
        public String getMainPurposeName() {
            return this.mainPurposeName;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurpose setMainPurposeType(String mainPurposeType) {
            this.mainPurposeType = mainPurposeType;
            return this;
        }
        public String getMainPurposeType() {
            return this.mainPurposeType;
        }

    }

    public static class QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfigOutputTagEnum extends TeaModel {
        /**
         * <p>The description of the tag enum value.</p>
         * 
         * <strong>example:</strong>
         * <p>High (very positive, high probability of conversion)</p>
         */
        @NameInMap("Description")
        public String description;

        /**
         * <p>The unique ID of the tag enum value.</p>
         * 
         * <strong>example:</strong>
         * <p>8757************2c499fa</p>
         */
        @NameInMap("Id")
        public String id;

        /**
         * <p>The tag enum value.</p>
         * 
         * <strong>example:</strong>
         * <p>High</p>
         */
        @NameInMap("Value")
        public String value;

        public static QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfigOutputTagEnum build(java.util.Map<String, ?> map) throws Exception {
            QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfigOutputTagEnum self = new QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfigOutputTagEnum();
            return TeaModel.build(map, self);
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfigOutputTagEnum setDescription(String description) {
            this.description = description;
            return this;
        }
        public String getDescription() {
            return this.description;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfigOutputTagEnum setId(String id) {
            this.id = id;
            return this;
        }
        public String getId() {
            return this.id;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfigOutputTagEnum setValue(String value) {
            this.value = value;
            return this;
        }
        public String getValue() {
            return this.value;
        }

    }

    public static class QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfig extends TeaModel {
        /**
         * <p>The unique ID of the tag.</p>
         * 
         * <strong>example:</strong>
         * <p>8757************2c499fa</p>
         */
        @NameInMap("Id")
        public String id;

        /**
         * <p>The tag description.</p>
         * 
         * <strong>example:</strong>
         * <p>Records the final status of this call</p>
         */
        @NameInMap("OutputTagDescription")
        public String outputTagDescription;

        /**
         * <p>The tag enum values. This field is available only when the tag value type is ENUM.</p>
         */
        @NameInMap("OutputTagEnum")
        public java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfigOutputTagEnum> outputTagEnum;

        /**
         * <p>The tag name.</p>
         * 
         * <strong>example:</strong>
         * <p>Customer intent level</p>
         */
        @NameInMap("OutputTagName")
        public String outputTagName;

        /**
         * <p>The tag value type.</p>
         * 
         * <strong>example:</strong>
         * <p>ENUM</p>
         */
        @NameInMap("OutputTagType")
        public String outputTagType;

        public static QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfig build(java.util.Map<String, ?> map) throws Exception {
            QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfig self = new QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfig();
            return TeaModel.build(map, self);
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfig setId(String id) {
            this.id = id;
            return this;
        }
        public String getId() {
            return this.id;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfig setOutputTagDescription(String outputTagDescription) {
            this.outputTagDescription = outputTagDescription;
            return this;
        }
        public String getOutputTagDescription() {
            return this.outputTagDescription;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfig setOutputTagEnum(java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfigOutputTagEnum> outputTagEnum) {
            this.outputTagEnum = outputTagEnum;
            return this;
        }
        public java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfigOutputTagEnum> getOutputTagEnum() {
            return this.outputTagEnum;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfig setOutputTagName(String outputTagName) {
            this.outputTagName = outputTagName;
            return this;
        }
        public String getOutputTagName() {
            return this.outputTagName;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfig setOutputTagType(String outputTagType) {
            this.outputTagType = outputTagType;
            return this;
        }
        public String getOutputTagType() {
            return this.outputTagType;
        }

    }

    public static class QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfigPhoneTagEnum extends TeaModel {
        /**
         * <p>The description of the enumeration value.</p>
         * 
         * <strong>example:</strong>
         * <p>The customer completely refuses retention</p>
         */
        @NameInMap("Description")
        public String description;

        /**
         * <p>The unique ID of the enum value.</p>
         * 
         * <strong>example:</strong>
         * <p>c3d4ff4e-*********bc26dc044682</p>
         */
        @NameInMap("Id")
        public String id;

        /**
         * <p>The enumeration value.</p>
         * 
         * <strong>example:</strong>
         * <p>Completely unacceptable</p>
         */
        @NameInMap("Value")
        public String value;

        public static QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfigPhoneTagEnum build(java.util.Map<String, ?> map) throws Exception {
            QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfigPhoneTagEnum self = new QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfigPhoneTagEnum();
            return TeaModel.build(map, self);
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfigPhoneTagEnum setDescription(String description) {
            this.description = description;
            return this;
        }
        public String getDescription() {
            return this.description;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfigPhoneTagEnum setId(String id) {
            this.id = id;
            return this;
        }
        public String getId() {
            return this.id;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfigPhoneTagEnum setValue(String value) {
            this.value = value;
            return this;
        }
        public String getValue() {
            return this.value;
        }

    }

    public static class QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfig extends TeaModel {
        /**
         * <p>The unique ID of the variable.</p>
         * 
         * <strong>example:</strong>
         * <p>280cd4bf-*******df472c</p>
         */
        @NameInMap("Id")
        public String id;

        /**
         * <p>The variable description.</p>
         * 
         * <strong>example:</strong>
         * <p>The vehicle series that the user is interested in</p>
         */
        @NameInMap("PhoneTagDescription")
        public String phoneTagDescription;

        /**
         * <p>The list of enumeration values for the variable. This field is available only when the variable value type is ENUM.</p>
         */
        @NameInMap("PhoneTagEnum")
        public java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfigPhoneTagEnum> phoneTagEnum;

        /**
         * <p>The variable key name.</p>
         * 
         * <strong>example:</strong>
         * <p>testParam</p>
         */
        @NameInMap("PhoneTagKey")
        public String phoneTagKey;

        /**
         * <p>The Chinese name of the variable.</p>
         * 
         * <strong>example:</strong>
         * <p>Intended vehicle series</p>
         */
        @NameInMap("PhoneTagName")
        public String phoneTagName;

        /**
         * <p>Specifies whether the variable is required.</p>
         * 
         * <strong>example:</strong>
         * <p>true</p>
         */
        @NameInMap("PhoneTagRequired")
        public Boolean phoneTagRequired;

        /**
         * <p>The source of the call variable.</p>
         * 
         * <strong>example:</strong>
         * <p>Sample value</p>
         */
        @NameInMap("PhoneTagSource")
        public String phoneTagSource;

        /**
         * <p>The variable value type.</p>
         * 
         * <strong>example:</strong>
         * <p>ENUM</p>
         */
        @NameInMap("PhoneTagType")
        public String phoneTagType;

        public static QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfig build(java.util.Map<String, ?> map) throws Exception {
            QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfig self = new QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfig();
            return TeaModel.build(map, self);
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfig setId(String id) {
            this.id = id;
            return this;
        }
        public String getId() {
            return this.id;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfig setPhoneTagDescription(String phoneTagDescription) {
            this.phoneTagDescription = phoneTagDescription;
            return this;
        }
        public String getPhoneTagDescription() {
            return this.phoneTagDescription;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfig setPhoneTagEnum(java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfigPhoneTagEnum> phoneTagEnum) {
            this.phoneTagEnum = phoneTagEnum;
            return this;
        }
        public java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfigPhoneTagEnum> getPhoneTagEnum() {
            return this.phoneTagEnum;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfig setPhoneTagKey(String phoneTagKey) {
            this.phoneTagKey = phoneTagKey;
            return this;
        }
        public String getPhoneTagKey() {
            return this.phoneTagKey;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfig setPhoneTagName(String phoneTagName) {
            this.phoneTagName = phoneTagName;
            return this;
        }
        public String getPhoneTagName() {
            return this.phoneTagName;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfig setPhoneTagRequired(Boolean phoneTagRequired) {
            this.phoneTagRequired = phoneTagRequired;
            return this;
        }
        public Boolean getPhoneTagRequired() {
            return this.phoneTagRequired;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfig setPhoneTagSource(String phoneTagSource) {
            this.phoneTagSource = phoneTagSource;
            return this;
        }
        public String getPhoneTagSource() {
            return this.phoneTagSource;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfig setPhoneTagType(String phoneTagType) {
            this.phoneTagType = phoneTagType;
            return this;
        }
        public String getPhoneTagType() {
            return this.phoneTagType;
        }

    }

    public static class QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig extends TeaModel {
        /**
         * <p>The basic task configuration.</p>
         * 
         * <strong>example:</strong>
         * <p>Task description</p>
         */
        @NameInMap("BasicTaskDescription")
        public String basicTaskDescription;

        /**
         * <p>The business scenario.</p>
         * 
         * <strong>example:</strong>
         * <p>1</p>
         */
        @NameInMap("BusinessType")
        public Long businessType;

        /**
         * <p>The list of child task configurations.</p>
         */
        @NameInMap("ChildTaskList")
        public java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigChildTaskList> childTaskList;

        /**
         * <p>Specifies whether to enable custom exception handling.</p>
         * 
         * <strong>example:</strong>
         * <p>false</p>
         */
        @NameInMap("CustomExceptionEnable")
        public Boolean customExceptionEnable;

        /**
         * <p>The custom exception file ID.</p>
         * 
         * <strong>example:</strong>
         * <p>OSS file ID</p>
         */
        @NameInMap("CustomExceptionFileId")
        public String customExceptionFileId;

        /**
         * <p>The custom exception file name.</p>
         * 
         * <strong>example:</strong>
         * <p>Exception test file.xlsx</p>
         */
        @NameInMap("CustomExceptionFileName")
        public String customExceptionFileName;

        /**
         * <p><strong>[Deprecated]</strong> This field is deprecated and will be removed in a future release.</p>
         */
        @NameInMap("CustomExceptionList")
        public java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigCustomExceptionList> customExceptionList;

        /**
         * <p><strong>[Deprecated]</strong> This field is deprecated and will be removed in a future release.</p>
         * 
         * <strong>example:</strong>
         * <ul>
         * <li></li>
         * </ul>
         */
        @NameInMap("CustomExceptionUrlPath")
        public String customExceptionUrlPath;

        /**
         * <p>The voice style.</p>
         * 
         * <strong>example:</strong>
         * <p>2</p>
         */
        @NameInMap("CustomExceptionVoiceStyle")
        public Long customExceptionVoiceStyle;

        /**
         * <p>The description of the advanced task flow.</p>
         * 
         * <strong>example:</strong>
         * <p>This outbound call communicates with parents through three core steps... 3. User needs &gt; Proactive introduction</p>
         */
        @NameInMap("FlowDesc")
        public String flowDesc;

        /**
         * <p>The list of knowledge document IDs.</p>
         */
        @NameInMap("KnowledgeDocIdList")
        public java.util.List<String> knowledgeDocIdList;

        /**
         * <p>The list of knowledge document names.</p>
         */
        @NameInMap("KnowledgeDocNameList")
        public java.util.List<String> knowledgeDocNameList;

        /**
         * <p>The list of original file names of the knowledge base documents.</p>
         */
        @NameInMap("KnowledgeDocOriginalNameList")
        public java.util.List<String> knowledgeDocOriginalNameList;

        /**
         * <p>Specifies whether to associate a knowledge base.</p>
         * 
         * <strong>example:</strong>
         * <p>false</p>
         */
        @NameInMap("KnowledgeEnable")
        public Boolean knowledgeEnable;

        /**
         * <p>The knowledge base ID.</p>
         * 
         * <strong>example:</strong>
         * <p>1232131*******</p>
         */
        @NameInMap("KnowledgeId")
        public String knowledgeId;

        /**
         * <p>The main intent configuration.</p>
         */
        @NameInMap("MainPurpose")
        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurpose mainPurpose;

        /**
         * <p>The output tag configuration.</p>
         */
        @NameInMap("OutputTagConfig")
        public java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfig> outputTagConfig;

        /**
         * <p>The call variable configuration.</p>
         */
        @NameInMap("PhoneTagConfig")
        public java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfig> phoneTagConfig;

        /**
         * <p>The opening speech.</p>
         * 
         * <strong>example:</strong>
         * <p>Hello, this is ******</p>
         */
        @NameInMap("Prologue")
        public String prologue;

        /**
         * <p>The URL of the opening remark audio file. This field has a value only when StartWordType is set to 1.</p>
         * 
         * <strong>example:</strong>
         * <p>Sample value</p>
         */
        @NameInMap("RecordingFile")
        public String recordingFile;

        /**
         * <p>The opening speech type. Valid values: 0: Text. 1: Recording.</p>
         * 
         * <strong>example:</strong>
         * <p>1</p>
         */
        @NameInMap("StartWordType")
        public Long startWordType;

        /**
         * <p>The system role.</p>
         * 
         * <strong>example:</strong>
         * <p>Course sales representative</p>
         */
        @NameInMap("SysRole")
        public String sysRole;

        /**
         * <p>The task type.</p>
         * 
         * <strong>example:</strong>
         * <p>ADVANCED</p>
         */
        @NameInMap("TaskType")
        public String taskType;

        /**
         * <p>The user role.</p>
         * 
         * <strong>example:</strong>
         * <p>New user in urgent need of courses</p>
         */
        @NameInMap("UserRole")
        public String userRole;

        public static QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig build(java.util.Map<String, ?> map) throws Exception {
            QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig self = new QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig();
            return TeaModel.build(map, self);
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setBasicTaskDescription(String basicTaskDescription) {
            this.basicTaskDescription = basicTaskDescription;
            return this;
        }
        public String getBasicTaskDescription() {
            return this.basicTaskDescription;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setBusinessType(Long businessType) {
            this.businessType = businessType;
            return this;
        }
        public Long getBusinessType() {
            return this.businessType;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setChildTaskList(java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigChildTaskList> childTaskList) {
            this.childTaskList = childTaskList;
            return this;
        }
        public java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigChildTaskList> getChildTaskList() {
            return this.childTaskList;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setCustomExceptionEnable(Boolean customExceptionEnable) {
            this.customExceptionEnable = customExceptionEnable;
            return this;
        }
        public Boolean getCustomExceptionEnable() {
            return this.customExceptionEnable;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setCustomExceptionFileId(String customExceptionFileId) {
            this.customExceptionFileId = customExceptionFileId;
            return this;
        }
        public String getCustomExceptionFileId() {
            return this.customExceptionFileId;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setCustomExceptionFileName(String customExceptionFileName) {
            this.customExceptionFileName = customExceptionFileName;
            return this;
        }
        public String getCustomExceptionFileName() {
            return this.customExceptionFileName;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setCustomExceptionList(java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigCustomExceptionList> customExceptionList) {
            this.customExceptionList = customExceptionList;
            return this;
        }
        public java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigCustomExceptionList> getCustomExceptionList() {
            return this.customExceptionList;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setCustomExceptionUrlPath(String customExceptionUrlPath) {
            this.customExceptionUrlPath = customExceptionUrlPath;
            return this;
        }
        public String getCustomExceptionUrlPath() {
            return this.customExceptionUrlPath;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setCustomExceptionVoiceStyle(Long customExceptionVoiceStyle) {
            this.customExceptionVoiceStyle = customExceptionVoiceStyle;
            return this;
        }
        public Long getCustomExceptionVoiceStyle() {
            return this.customExceptionVoiceStyle;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setFlowDesc(String flowDesc) {
            this.flowDesc = flowDesc;
            return this;
        }
        public String getFlowDesc() {
            return this.flowDesc;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setKnowledgeDocIdList(java.util.List<String> knowledgeDocIdList) {
            this.knowledgeDocIdList = knowledgeDocIdList;
            return this;
        }
        public java.util.List<String> getKnowledgeDocIdList() {
            return this.knowledgeDocIdList;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setKnowledgeDocNameList(java.util.List<String> knowledgeDocNameList) {
            this.knowledgeDocNameList = knowledgeDocNameList;
            return this;
        }
        public java.util.List<String> getKnowledgeDocNameList() {
            return this.knowledgeDocNameList;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setKnowledgeDocOriginalNameList(java.util.List<String> knowledgeDocOriginalNameList) {
            this.knowledgeDocOriginalNameList = knowledgeDocOriginalNameList;
            return this;
        }
        public java.util.List<String> getKnowledgeDocOriginalNameList() {
            return this.knowledgeDocOriginalNameList;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setKnowledgeEnable(Boolean knowledgeEnable) {
            this.knowledgeEnable = knowledgeEnable;
            return this;
        }
        public Boolean getKnowledgeEnable() {
            return this.knowledgeEnable;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setKnowledgeId(String knowledgeId) {
            this.knowledgeId = knowledgeId;
            return this;
        }
        public String getKnowledgeId() {
            return this.knowledgeId;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setMainPurpose(QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurpose mainPurpose) {
            this.mainPurpose = mainPurpose;
            return this;
        }
        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigMainPurpose getMainPurpose() {
            return this.mainPurpose;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setOutputTagConfig(java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfig> outputTagConfig) {
            this.outputTagConfig = outputTagConfig;
            return this;
        }
        public java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigOutputTagConfig> getOutputTagConfig() {
            return this.outputTagConfig;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setPhoneTagConfig(java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfig> phoneTagConfig) {
            this.phoneTagConfig = phoneTagConfig;
            return this;
        }
        public java.util.List<QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfigPhoneTagConfig> getPhoneTagConfig() {
            return this.phoneTagConfig;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setPrologue(String prologue) {
            this.prologue = prologue;
            return this;
        }
        public String getPrologue() {
            return this.prologue;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setRecordingFile(String recordingFile) {
            this.recordingFile = recordingFile;
            return this;
        }
        public String getRecordingFile() {
            return this.recordingFile;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setStartWordType(Long startWordType) {
            this.startWordType = startWordType;
            return this;
        }
        public Long getStartWordType() {
            return this.startWordType;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setSysRole(String sysRole) {
            this.sysRole = sysRole;
            return this;
        }
        public String getSysRole() {
            return this.sysRole;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setTaskType(String taskType) {
            this.taskType = taskType;
            return this;
        }
        public String getTaskType() {
            return this.taskType;
        }

        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig setUserRole(String userRole) {
            this.userRole = userRole;
            return this;
        }
        public String getUserRole() {
            return this.userRole;
        }

    }

    public static class QueryAiVoiceAgentDetailResponseBodyData extends TeaModel {
        /**
         * <p>The agent ID.</p>
         * 
         * <strong>example:</strong>
         * <p>12311212******</p>
         */
        @NameInMap("AgentId")
        public Long agentId;

        /**
         * <p>The agent name.</p>
         * 
         * <strong>example:</strong>
         * <p>Test agent</p>
         */
        @NameInMap("AgentName")
        public String agentName;

        /**
         * <p>The intelligent outbound call voice configuration.</p>
         */
        @NameInMap("AiVoiceAgentCallConfig")
        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfig aiVoiceAgentCallConfig;

        /**
         * <p>The agent model configuration.</p>
         */
        @NameInMap("AiVoiceAgentModelConfig")
        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig aiVoiceAgentModelConfig;

        /**
         * <p>The business scenario name.</p>
         * 
         * <strong>example:</strong>
         * <p>Personal lead conversion</p>
         */
        @NameInMap("BusinessTypeName")
        public String businessTypeName;

        /**
         * <p>The agent description.</p>
         * 
         * <strong>example:</strong>
         * <p>Used for daily testing</p>
         */
        @NameInMap("Description")
        public String description;

        /**
         * <p>The knowledge base name.</p>
         * 
         * <strong>example:</strong>
         * <p>Test knowledge base</p>
         */
        @NameInMap("KnowledgeName")
        public String knowledgeName;

        /**
         * <p>The agent status.</p>
         * 
         * <strong>example:</strong>
         * <p>7</p>
         */
        @NameInMap("Status")
        public Long status;

        /**
         * <p>The voice style name.</p>
         * 
         * <strong>example:</strong>
         * <p>Friendly</p>
         */
        @NameInMap("VoiceStyleName")
        public String voiceStyleName;

        public static QueryAiVoiceAgentDetailResponseBodyData build(java.util.Map<String, ?> map) throws Exception {
            QueryAiVoiceAgentDetailResponseBodyData self = new QueryAiVoiceAgentDetailResponseBodyData();
            return TeaModel.build(map, self);
        }

        public QueryAiVoiceAgentDetailResponseBodyData setAgentId(Long agentId) {
            this.agentId = agentId;
            return this;
        }
        public Long getAgentId() {
            return this.agentId;
        }

        public QueryAiVoiceAgentDetailResponseBodyData setAgentName(String agentName) {
            this.agentName = agentName;
            return this;
        }
        public String getAgentName() {
            return this.agentName;
        }

        public QueryAiVoiceAgentDetailResponseBodyData setAiVoiceAgentCallConfig(QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfig aiVoiceAgentCallConfig) {
            this.aiVoiceAgentCallConfig = aiVoiceAgentCallConfig;
            return this;
        }
        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentCallConfig getAiVoiceAgentCallConfig() {
            return this.aiVoiceAgentCallConfig;
        }

        public QueryAiVoiceAgentDetailResponseBodyData setAiVoiceAgentModelConfig(QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig aiVoiceAgentModelConfig) {
            this.aiVoiceAgentModelConfig = aiVoiceAgentModelConfig;
            return this;
        }
        public QueryAiVoiceAgentDetailResponseBodyDataAiVoiceAgentModelConfig getAiVoiceAgentModelConfig() {
            return this.aiVoiceAgentModelConfig;
        }

        public QueryAiVoiceAgentDetailResponseBodyData setBusinessTypeName(String businessTypeName) {
            this.businessTypeName = businessTypeName;
            return this;
        }
        public String getBusinessTypeName() {
            return this.businessTypeName;
        }

        public QueryAiVoiceAgentDetailResponseBodyData setDescription(String description) {
            this.description = description;
            return this;
        }
        public String getDescription() {
            return this.description;
        }

        public QueryAiVoiceAgentDetailResponseBodyData setKnowledgeName(String knowledgeName) {
            this.knowledgeName = knowledgeName;
            return this;
        }
        public String getKnowledgeName() {
            return this.knowledgeName;
        }

        public QueryAiVoiceAgentDetailResponseBodyData setStatus(Long status) {
            this.status = status;
            return this;
        }
        public Long getStatus() {
            return this.status;
        }

        public QueryAiVoiceAgentDetailResponseBodyData setVoiceStyleName(String voiceStyleName) {
            this.voiceStyleName = voiceStyleName;
            return this;
        }
        public String getVoiceStyleName() {
            return this.voiceStyleName;
        }

    }

}
