// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.aiccs20191015.models;

import com.aliyun.tea.*;

public class MakeDoubleCallResponse extends TeaModel {
    @NameInMap("headers")
    public java.util.Map<String, String> headers;

    @NameInMap("statusCode")
    public Integer statusCode;

    @NameInMap("body")
    public MakeDoubleCallResponseBody body;

    public static MakeDoubleCallResponse build(java.util.Map<String, ?> map) throws Exception {
        MakeDoubleCallResponse self = new MakeDoubleCallResponse();
        return TeaModel.build(map, self);
    }

    public MakeDoubleCallResponse setHeaders(java.util.Map<String, String> headers) {
        this.headers = headers;
        return this;
    }
    public java.util.Map<String, String> getHeaders() {
        return this.headers;
    }

    public MakeDoubleCallResponse setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
        return this;
    }
    public Integer getStatusCode() {
        return this.statusCode;
    }

    public MakeDoubleCallResponse setBody(MakeDoubleCallResponseBody body) {
        this.body = body;
        return this;
    }
    public MakeDoubleCallResponseBody getBody() {
        return this.body;
    }

}
