// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.aiccs20191015.models;

import com.aliyun.tea.*;

public class AiccsSmartCallOperateResponse extends TeaModel {
    @NameInMap("headers")
    public java.util.Map<String, String> headers;

    @NameInMap("statusCode")
    public Integer statusCode;

    @NameInMap("body")
    public AiccsSmartCallOperateResponseBody body;

    public static AiccsSmartCallOperateResponse build(java.util.Map<String, ?> map) throws Exception {
        AiccsSmartCallOperateResponse self = new AiccsSmartCallOperateResponse();
        return TeaModel.build(map, self);
    }

    public AiccsSmartCallOperateResponse setHeaders(java.util.Map<String, String> headers) {
        this.headers = headers;
        return this;
    }
    public java.util.Map<String, String> getHeaders() {
        return this.headers;
    }

    public AiccsSmartCallOperateResponse setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
        return this;
    }
    public Integer getStatusCode() {
        return this.statusCode;
    }

    public AiccsSmartCallOperateResponse setBody(AiccsSmartCallOperateResponseBody body) {
        this.body = body;
        return this;
    }
    public AiccsSmartCallOperateResponseBody getBody() {
        return this.body;
    }

}
