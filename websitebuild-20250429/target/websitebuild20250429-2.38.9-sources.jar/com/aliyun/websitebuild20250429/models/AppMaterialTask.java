// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.websitebuild20250429.models;

import com.aliyun.tea.*;

public class AppMaterialTask extends TeaModel {
    /**
     * <p>The business group ID.</p>
     * 
     * <strong>example:</strong>
     * <p>111</p>
     */
    @NameInMap("BizGroupId")
    public String bizGroupId;

    /**
     * <p>The task completion time.</p>
     * 
     * <strong>example:</strong>
     * <p>2025-12-26 11:30:05</p>
     */
    @NameInMap("CompleteTime")
    public String completeTime;

    /**
     * <p>The display format of the completion time.</p>
     * 
     * <strong>example:</strong>
     * <p>1 minute ago</p>
     */
    @NameInMap("CompleteTimeFormat")
    public String completeTimeFormat;

    /**
     * <p>The failure reason.</p>
     * 
     * <strong>example:</strong>
     * <p>Invalid parameters</p>
     */
    @NameInMap("FailReason")
    public String failReason;

    /**
     * <p>The list of final files.</p>
     */
    @NameInMap("FinalFileUrls")
    public java.util.List<String> finalFileUrls;

    /**
     * <p>The task status.</p>
     * 
     * <strong>example:</strong>
     * <p>RUNNING</p>
     */
    @NameInMap("Status")
    public String status;

    /**
     * <p>The task substatus.</p>
     * 
     * <strong>example:</strong>
     * <p>PENDING</p>
     */
    @NameInMap("SubStatus")
    public String subStatus;

    /**
     * <p>The submit time.</p>
     * 
     * <strong>example:</strong>
     * <p>2025-12-26 11:30:05</p>
     */
    @NameInMap("SubmitTime")
    public String submitTime;

    /**
     * <p>The task ID.</p>
     * 
     * <strong>example:</strong>
     * <p>81d04d62c3483b32bacf1d306d2622b2</p>
     */
    @NameInMap("TaskId")
    public String taskId;

    /**
     * <p>The task parameters.</p>
     * 
     * <strong>example:</strong>
     * <p>{
     *     &quot;brandName&quot;: &quot;Brand name&quot;,
     *     &quot;direction&quot;: &quot;HORIZONTAL&quot;,
     *     &quot;userPrompt&quot;: &quot;Design requirements&quot;
     * }</p>
     */
    @NameInMap("TaskParam")
    public String taskParam;

    /**
     * <p>The task type.</p>
     * 
     * <strong>example:</strong>
     * <p>IMAGE_LOGO</p>
     */
    @NameInMap("TaskType")
    public String taskType;

    public static AppMaterialTask build(java.util.Map<String, ?> map) throws Exception {
        AppMaterialTask self = new AppMaterialTask();
        return TeaModel.build(map, self);
    }

    public AppMaterialTask setBizGroupId(String bizGroupId) {
        this.bizGroupId = bizGroupId;
        return this;
    }
    public String getBizGroupId() {
        return this.bizGroupId;
    }

    public AppMaterialTask setCompleteTime(String completeTime) {
        this.completeTime = completeTime;
        return this;
    }
    public String getCompleteTime() {
        return this.completeTime;
    }

    public AppMaterialTask setCompleteTimeFormat(String completeTimeFormat) {
        this.completeTimeFormat = completeTimeFormat;
        return this;
    }
    public String getCompleteTimeFormat() {
        return this.completeTimeFormat;
    }

    public AppMaterialTask setFailReason(String failReason) {
        this.failReason = failReason;
        return this;
    }
    public String getFailReason() {
        return this.failReason;
    }

    public AppMaterialTask setFinalFileUrls(java.util.List<String> finalFileUrls) {
        this.finalFileUrls = finalFileUrls;
        return this;
    }
    public java.util.List<String> getFinalFileUrls() {
        return this.finalFileUrls;
    }

    public AppMaterialTask setStatus(String status) {
        this.status = status;
        return this;
    }
    public String getStatus() {
        return this.status;
    }

    public AppMaterialTask setSubStatus(String subStatus) {
        this.subStatus = subStatus;
        return this;
    }
    public String getSubStatus() {
        return this.subStatus;
    }

    public AppMaterialTask setSubmitTime(String submitTime) {
        this.submitTime = submitTime;
        return this;
    }
    public String getSubmitTime() {
        return this.submitTime;
    }

    public AppMaterialTask setTaskId(String taskId) {
        this.taskId = taskId;
        return this;
    }
    public String getTaskId() {
        return this.taskId;
    }

    public AppMaterialTask setTaskParam(String taskParam) {
        this.taskParam = taskParam;
        return this;
    }
    public String getTaskParam() {
        return this.taskParam;
    }

    public AppMaterialTask setTaskType(String taskType) {
        this.taskType = taskType;
        return this;
    }
    public String getTaskType() {
        return this.taskType;
    }

}
