// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.websitebuild20250429.models;

import com.aliyun.tea.*;

public class GetUserAccessTokenForPartnerResponseBody extends TeaModel {
    /**
     * <p>The error code. If the request is successful, the ErrorCode field is not returned. If the request fails, the ErrorCode field is returned. For more information, see the error codes in this topic.</p>
     * 
     * <strong>example:</strong>
     * <p>0</p>
     */
    @NameInMap("ErrorCode")
    public String errorCode;

    /**
     * <p>The response data.</p>
     */
    @NameInMap("Module")
    public GetUserAccessTokenForPartnerResponseBodyModule module;

    /**
     * <p>Id of the request</p>
     * 
     * <strong>example:</strong>
     * <p>6C6B99AC-39EC-5350-874C-204128C905E6</p>
     */
    @NameInMap("RequestId")
    public String requestId;

    /**
     * <p>Indicates whether the request is successful.</p>
     * 
     * <strong>example:</strong>
     * <p>true</p>
     */
    @NameInMap("Success")
    public String success;

    public static GetUserAccessTokenForPartnerResponseBody build(java.util.Map<String, ?> map) throws Exception {
        GetUserAccessTokenForPartnerResponseBody self = new GetUserAccessTokenForPartnerResponseBody();
        return TeaModel.build(map, self);
    }

    public GetUserAccessTokenForPartnerResponseBody setErrorCode(String errorCode) {
        this.errorCode = errorCode;
        return this;
    }
    public String getErrorCode() {
        return this.errorCode;
    }

    public GetUserAccessTokenForPartnerResponseBody setModule(GetUserAccessTokenForPartnerResponseBodyModule module) {
        this.module = module;
        return this;
    }
    public GetUserAccessTokenForPartnerResponseBodyModule getModule() {
        return this.module;
    }

    public GetUserAccessTokenForPartnerResponseBody setRequestId(String requestId) {
        this.requestId = requestId;
        return this;
    }
    public String getRequestId() {
        return this.requestId;
    }

    public GetUserAccessTokenForPartnerResponseBody setSuccess(String success) {
        this.success = success;
        return this;
    }
    public String getSuccess() {
        return this.success;
    }

    public static class GetUserAccessTokenForPartnerResponseBodyModule extends TeaModel {
        /**
         * <p>The value of the exchanged access token.</p>
         * 
         * <strong>example:</strong>
         * <p>000a00000a000000000000000a000000000a0a00000000000000000a0a00000a000000000000000a000000000000000a0a0a000000000a0a0000000000000000000000000a0000000a00000a0a000a000a00000000000a0a</p>
         */
        @NameInMap("TokenValue")
        public String tokenValue;

        public static GetUserAccessTokenForPartnerResponseBodyModule build(java.util.Map<String, ?> map) throws Exception {
            GetUserAccessTokenForPartnerResponseBodyModule self = new GetUserAccessTokenForPartnerResponseBodyModule();
            return TeaModel.build(map, self);
        }

        public GetUserAccessTokenForPartnerResponseBodyModule setTokenValue(String tokenValue) {
            this.tokenValue = tokenValue;
            return this;
        }
        public String getTokenValue() {
            return this.tokenValue;
        }

    }

}
