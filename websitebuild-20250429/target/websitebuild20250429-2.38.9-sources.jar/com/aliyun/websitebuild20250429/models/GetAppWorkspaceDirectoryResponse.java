// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.websitebuild20250429.models;

import com.aliyun.tea.*;

public class GetAppWorkspaceDirectoryResponse extends TeaModel {
    @NameInMap("headers")
    public java.util.Map<String, String> headers;

    @NameInMap("statusCode")
    public Integer statusCode;

    @NameInMap("body")
    public GetAppWorkspaceDirectoryResponseBody body;

    public static GetAppWorkspaceDirectoryResponse build(java.util.Map<String, ?> map) throws Exception {
        GetAppWorkspaceDirectoryResponse self = new GetAppWorkspaceDirectoryResponse();
        return TeaModel.build(map, self);
    }

    public GetAppWorkspaceDirectoryResponse setHeaders(java.util.Map<String, String> headers) {
        this.headers = headers;
        return this;
    }
    public java.util.Map<String, String> getHeaders() {
        return this.headers;
    }

    public GetAppWorkspaceDirectoryResponse setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
        return this;
    }
    public Integer getStatusCode() {
        return this.statusCode;
    }

    public GetAppWorkspaceDirectoryResponse setBody(GetAppWorkspaceDirectoryResponseBody body) {
        this.body = body;
        return this;
    }
    public GetAppWorkspaceDirectoryResponseBody getBody() {
        return this.body;
    }

}
