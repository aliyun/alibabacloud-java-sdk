// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.rds20140815.models;

import com.aliyun.tea.*;

public class ModifyAccountSecurityPolicyRequest extends TeaModel {
    /**
     * <p>The client token that is used to ensure the idempotence of the request and prevent duplicate submissions. You can use the client to generate the value, but you must ensure that it is unique among different requests. The token can contain only ASCII characters and cannot exceed 64 characters in length.</p>
     * 
     * <strong>example:</strong>
     * <p>ETnLKlblzczshOTUbOCz****</p>
     */
    @NameInMap("ClientToken")
    public String clientToken;

    /**
     * <p>Instance ID of the instance. You can call the <a href="https://help.aliyun.com/document_detail/2628785.html">DescribeDBInstances</a> operation to query instance ID.</p>
     * <p>This parameter is required.</p>
     * 
     * <strong>example:</strong>
     * <p>rm-bp1ibu****</p>
     */
    @NameInMap("DBInstanceId")
    public String DBInstanceId;

    /**
     * <p>The custom account password policy for ApsaraDB RDS for SQL Server. Supported policies:</p>
     * <ul>
     * <li>Set only the maximum password age. The password must be changed after this period: <code>{&quot;accountSecurityPolicy&quot;: {&quot;MaximumPasswordAge&quot;: &lt;maximum_age&gt;}}</code></li>
     * <li>Set only the minimum password age. The password cannot be changed again within this period: <code>{&quot;accountSecurityPolicy&quot;: {&quot;MinimumPasswordAge&quot;: &lt;minimum_age&gt;}}</code></li>
     * <li>Set both the maximum and minimum password ages: <code>{&quot;accountSecurityPolicy&quot;: {&quot;MaximumPasswordAge&quot;: &lt;maximum_age&gt;, &quot;MinimumPasswordAge&quot;: &lt;minimum_age&gt;}}</code></li>
     * </ul>
     * <blockquote>
     * <p>The minimum password age (valid values: 0 to 998) cannot be greater than the maximum password age (valid values: 0 to 999).</p>
     * </blockquote>
     * <p>This parameter is required.</p>
     * 
     * <strong>example:</strong>
     * <p>{&quot;accountSecurityPolicy&quot;: {&quot;MaximumPasswordAge&quot;: 30, &quot;MinimumPasswordAge&quot;: 20}}</p>
     */
    @NameInMap("GroupPolicy")
    public String groupPolicy;

    @NameInMap("OwnerAccount")
    public String ownerAccount;

    @NameInMap("OwnerId")
    public Long ownerId;

    /**
     * <p>The ID of the resource group.</p>
     * 
     * <strong>example:</strong>
     * <p>rg-acfmy****</p>
     */
    @NameInMap("ResourceGroupId")
    public String resourceGroupId;

    @NameInMap("ResourceOwnerAccount")
    public String resourceOwnerAccount;

    @NameInMap("ResourceOwnerId")
    public Long resourceOwnerId;

    public static ModifyAccountSecurityPolicyRequest build(java.util.Map<String, ?> map) throws Exception {
        ModifyAccountSecurityPolicyRequest self = new ModifyAccountSecurityPolicyRequest();
        return TeaModel.build(map, self);
    }

    public ModifyAccountSecurityPolicyRequest setClientToken(String clientToken) {
        this.clientToken = clientToken;
        return this;
    }
    public String getClientToken() {
        return this.clientToken;
    }

    public ModifyAccountSecurityPolicyRequest setDBInstanceId(String DBInstanceId) {
        this.DBInstanceId = DBInstanceId;
        return this;
    }
    public String getDBInstanceId() {
        return this.DBInstanceId;
    }

    public ModifyAccountSecurityPolicyRequest setGroupPolicy(String groupPolicy) {
        this.groupPolicy = groupPolicy;
        return this;
    }
    public String getGroupPolicy() {
        return this.groupPolicy;
    }

    public ModifyAccountSecurityPolicyRequest setOwnerAccount(String ownerAccount) {
        this.ownerAccount = ownerAccount;
        return this;
    }
    public String getOwnerAccount() {
        return this.ownerAccount;
    }

    public ModifyAccountSecurityPolicyRequest setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
        return this;
    }
    public Long getOwnerId() {
        return this.ownerId;
    }

    public ModifyAccountSecurityPolicyRequest setResourceGroupId(String resourceGroupId) {
        this.resourceGroupId = resourceGroupId;
        return this;
    }
    public String getResourceGroupId() {
        return this.resourceGroupId;
    }

    public ModifyAccountSecurityPolicyRequest setResourceOwnerAccount(String resourceOwnerAccount) {
        this.resourceOwnerAccount = resourceOwnerAccount;
        return this;
    }
    public String getResourceOwnerAccount() {
        return this.resourceOwnerAccount;
    }

    public ModifyAccountSecurityPolicyRequest setResourceOwnerId(Long resourceOwnerId) {
        this.resourceOwnerId = resourceOwnerId;
        return this;
    }
    public Long getResourceOwnerId() {
        return this.resourceOwnerId;
    }

}
