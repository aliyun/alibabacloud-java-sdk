// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.rds20140815.models;

import com.aliyun.tea.*;

public class DescribeRCInstanceAttributeResponseBody extends TeaModel {
    /**
     * <p>Indicates whether auto-renewal is enabled for the instance. Valid values:</p>
     * <ul>
     * <li><strong>true</strong>: Yes.</li>
     * <li><strong>false</strong>: No.</li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>false</p>
     */
    @NameInMap("AutoRenew")
    public Boolean autoRenew;

    /**
     * <p>The ID of the cluster to which the instance belongs.</p>
     * <blockquote>
     * <p>This parameter will be deprecated. To ensure compatibility, use other parameters instead.</p>
     * </blockquote>
     * 
     * <strong>example:</strong>
     * <p>None</p>
     */
    @NameInMap("ClusterId")
    public String clusterId;

    /**
     * <p>The number of vCPUs.</p>
     * 
     * <strong>example:</strong>
     * <p>4</p>
     */
    @NameInMap("Cpu")
    public Integer cpu;

    /**
     * <p>Indicates whether the instance is added to an ACK cluster. Valid values:</p>
     * <ul>
     * <li><strong>1</strong>: Yes.</li>
     * <li><strong>0</strong>: No.</li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>0</p>
     */
    @NameInMap("CreateMode")
    public Integer createMode;

    /**
     * <p>The time when the instance was created. The time is displayed in UTC and follows the ISO 8601 standard in the yyyy-MM-ddTHH:mmZ format.</p>
     * 
     * <strong>example:</strong>
     * <p>2024-04-22T06:52:23Z</p>
     */
    @NameInMap("CreationTime")
    public String creationTime;

    /**
     * <p>The performance mode of the burstable instance.</p>
     * 
     * <strong>example:</strong>
     * <p>None</p>
     */
    @NameInMap("CreditSpecification")
    public String creditSpecification;

    @NameInMap("DataDisks")
    public DescribeRCInstanceAttributeResponseBodyDataDisks dataDisks;

    /**
     * <p>The database engine type. Valid values:</p>
     * <ul>
     * <li><strong>mssql</strong>: SQL Server.</li>
     * <li><strong>mysql</strong>: MySQL.</li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>mysql</p>
     */
    @NameInMap("DbType")
    public String dbType;

    /**
     * <p>The dedicated host attributes.</p>
     * 
     * <strong>if can be null:</strong>
     * <p>true</p>
     */
    @NameInMap("DedicatedHostAttribute")
    public DescribeRCInstanceAttributeResponseBodyDedicatedHostAttribute dedicatedHostAttribute;

    /**
     * <p>Indicates whether release protection is enabled. Valid values:</p>
     * <ul>
     * <li><strong>true</strong>: Enabled.</li>
     * <li><strong>false</strong>: Disabled.</li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>false</p>
     * 
     * <strong>if can be null:</strong>
     * <p>false</p>
     */
    @NameInMap("DeletionProtection")
    public Boolean deletionProtection;

    /**
     * <p>The ID of the deployment set.</p>
     * 
     * <strong>example:</strong>
     * <p>ds-uf6c8qerk019bj1l****</p>
     */
    @NameInMap("DeploymentSetId")
    public String deploymentSetId;

    /**
     * <p>The description of the instance.</p>
     * 
     * <strong>example:</strong>
     * <p>test</p>
     */
    @NameInMap("Description")
    public String description;

    /**
     * <p>A reserved parameter.</p>
     * 
     * <strong>example:</strong>
     * <p>None</p>
     */
    @NameInMap("DiskType")
    public String diskType;

    /**
     * <p>The corresponding ECS instance family.</p>
     * 
     * <strong>example:</strong>
     * <p>ecs.g6.2xlarge</p>
     */
    @NameInMap("EcsInstanceType")
    public String ecsInstanceType;

    /**
     * <p>The information about the associated elastic IP address (EIP).</p>
     */
    @NameInMap("EipAddress")
    public DescribeRCInstanceAttributeResponseBodyEipAddress eipAddress;

    /**
     * <p>Indicates whether the jumbo frame feature is enabled for the instance. Valid values:</p>
     * <ul>
     * <li><p><strong>true</strong>: Enabled.</p>
     * </li>
     * <li><p><strong>false</strong>: Disabled.</p>
     * </li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>false</p>
     */
    @NameInMap("EnableJumboFrame")
    public Boolean enableJumboFrame;

    /**
     * <p>The expiration time. The time is displayed in UTC and follows the ISO 8601 standard in the yyyy-MM-ddTHH:mmZ format.</p>
     * 
     * <strong>example:</strong>
     * <p>2024-08-10T00:00:00Z</p>
     */
    @NameInMap("ExpiredTime")
    public String expiredTime;

    /**
     * <p>The number of GPUs.</p>
     * 
     * <strong>example:</strong>
     * <p>2</p>
     * 
     * <strong>if can be null:</strong>
     * <p>false</p>
     */
    @NameInMap("Gpu")
    public Integer gpu;

    /**
     * <p>The GPU type.</p>
     * 
     * <strong>example:</strong>
     * <p>NVIDIA V100</p>
     */
    @NameInMap("GpuTypes")
    public String gpuTypes;

    /**
     * <p>The hostname of the instance.</p>
     * 
     * <strong>example:</strong>
     * <p>iZ2zej1n3cin51rlmby****</p>
     */
    @NameInMap("HostName")
    public String hostName;

    /**
     * <p>The host storage type. Valid values:</p>
     * <ul>
     * <li><strong>dhg_cloud_ssd</strong>: standard SSD.</li>
     * <li><strong>dhg_local_ssd</strong>: local SSD.</li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>dhg_cloud_ssd</p>
     */
    @NameInMap("HostType")
    public String hostType;

    /**
     * <p>The ID of the image that the instance runs.</p>
     * 
     * <strong>example:</strong>
     * <p>m-2oqiu973jwcxe****</p>
     */
    @NameInMap("ImageId")
    public String imageId;

    @NameInMap("InnerIpAddress")
    public DescribeRCInstanceAttributeResponseBodyInnerIpAddress innerIpAddress;

    /**
     * <p>The billing method of the instance. Valid values:</p>
     * <ul>
     * <li><strong>PrePaid</strong>: subscription.</li>
     * <li><strong>PostPaid</strong>: pay-as-you-go.</li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>PostPaid</p>
     */
    @NameInMap("InstanceChargeType")
    public String instanceChargeType;

    /**
     * <p>The instance ID.</p>
     * 
     * <strong>example:</strong>
     * <p>rc-dh2jf9n6j4s14926****</p>
     */
    @NameInMap("InstanceId")
    public String instanceId;

    /**
     * <p>The name of the instance.</p>
     * 
     * <strong>example:</strong>
     * <p>test</p>
     */
    @NameInMap("InstanceName")
    public String instanceName;

    /**
     * <p>The network type. Valid values: </p>
     * <ul>
     * <li><strong>classic</strong>: classic network.</li>
     * <li><strong>vpc</strong>: virtual private cloud (VPC).</li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>vpc</p>
     */
    @NameInMap("InstanceNetworkType")
    public String instanceNetworkType;

    /**
     * <p>The instance type.</p>
     * 
     * <strong>example:</strong>
     * <p>mysql.x4.xlarge.6cm</p>
     */
    @NameInMap("InstanceType")
    public String instanceType;

    /**
     * <p>The billing method for Internet bandwidth. Valid values:</p>
     * <ul>
     * <li><strong>PayByBandwidth</strong>: pay-by-bandwidth.</li>
     * <li><strong>PayByTraffic</strong>: pay-by-traffic.</li>
     * </ul>
     * <blockquote>
     * <p>In the <strong>pay-by-traffic</strong> pattern, the peak inbound and outbound bandwidth values are upper limits and are not guaranteed. During resource contention, the peak bandwidth may be limited. If your business requires guaranteed bandwidth, use the <strong>pay-by-bandwidth</strong> pattern.</p>
     * </blockquote>
     * 
     * <strong>example:</strong>
     * <p>PayByTraffic</p>
     */
    @NameInMap("InternetChargeType")
    public String internetChargeType;

    /**
     * <p>The maximum inbound public bandwidth. Unit: Mbit/s.</p>
     * 
     * <strong>example:</strong>
     * <p>1</p>
     */
    @NameInMap("InternetMaxBandwidthIn")
    public Integer internetMaxBandwidthIn;

    /**
     * <p>The maximum outbound public bandwidth. Unit: Mbit/s.</p>
     * 
     * <strong>example:</strong>
     * <p>5</p>
     */
    @NameInMap("InternetMaxBandwidthOut")
    public Integer internetMaxBandwidthOut;

    /**
     * <p>Indicates whether the instance is an I/O optimized instance. Valid values:</p>
     * <ul>
     * <li><strong>optimized</strong>: I/O optimization.</li>
     * <li><strong>none</strong>: No I/O optimization.</li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>optimized</p>
     */
    @NameInMap("IoOptimized")
    public String ioOptimized;

    /**
     * <p>The name of the key pair.</p>
     * 
     * <strong>example:</strong>
     * <p>test_01</p>
     */
    @NameInMap("KeyPairName")
    public String keyPairName;

    /**
     * <p>The memory size. Unit: MiB.</p>
     * 
     * <strong>example:</strong>
     * <p>8192</p>
     */
    @NameInMap("Memory")
    public Integer memory;

    /**
     * <p>The node type. A value of <strong>rds_vnode</strong> indicates that the node is a container node.</p>
     * 
     * <strong>example:</strong>
     * <p>rds_vnode</p>
     */
    @NameInMap("NodeType")
    public String nodeType;

    @NameInMap("OperationLocks")
    public DescribeRCInstanceAttributeResponseBodyOperationLocks operationLocks;

    @NameInMap("PublicIpAddress")
    public DescribeRCInstanceAttributeResponseBodyPublicIpAddress publicIpAddress;

    /**
     * <p>The region ID.</p>
     * 
     * <strong>example:</strong>
     * <p>cn-hangzhou</p>
     */
    @NameInMap("RegionId")
    public String regionId;

    /**
     * <p>The request ID.</p>
     * 
     * <strong>example:</strong>
     * <p>EA2D4F34-01A7-46EB-A339-D80882135206</p>
     */
    @NameInMap("RequestId")
    public String requestId;

    /**
     * <p>The ID of the resource group.</p>
     * 
     * <strong>example:</strong>
     * <p>rg-aeky6z354ks****</p>
     */
    @NameInMap("ResourceGroupId")
    public String resourceGroupId;

    @NameInMap("SecurityGroupIds")
    public DescribeRCInstanceAttributeResponseBodySecurityGroupIds securityGroupIds;

    /**
     * <p>The serial number of the instance.</p>
     * 
     * <strong>example:</strong>
     * <p>b076f6ff-46d1-4234-a608-4e951ed6****</p>
     */
    @NameInMap("SerialNumber")
    public String serialNumber;

    /**
     * <p>The bidding policy for the pay-as-you-go instance. Valid values:</p>
     * <ul>
     * <li><strong>NoSpot</strong>: The instance is a regular pay-as-you-go instance.</li>
     * <li><strong>SpotAsPriceGo</strong>: The system automatically bids based on the current market price.</li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>NoSpot</p>
     */
    @NameInMap("SpotStrategy")
    public String spotStrategy;

    /**
     * <p>The instance status. Valid values:</p>
     * <ul>
     * <li><strong>Pending</strong>: The instance is being created.</li>
     * <li><strong>Running</strong>: The instance is running.</li>
     * <li><strong>Starting</strong>: The instance is starting.</li>
     * <li><strong>Stopping</strong>: The instance is pausing.</li>
     * <li><strong>Stopped</strong>: The instance is in a pause state.</li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>Running</p>
     */
    @NameInMap("Status")
    public String status;

    /**
     * <p>Indicates whether the instance continues to be billed after it is stopped. Valid values:</p>
     * <ul>
     * <li><strong>KeepCharging</strong>: The instance continues to be billed after it is stopped, and resources are reserved.</li>
     * <li><strong>StopCharging</strong>: The instance is not billed after it is stopped. After the instance is stopped, resources such as vCPUs, memory, and public IP addresses are released. Whether the instance can be successfully restarted depends on resource availability in the current region.</li>
     * <li><strong>Not-applicable</strong>: The instance does not support the no fees for stopped instances feature.</li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>Not-applicable</p>
     */
    @NameInMap("StoppedMode")
    public String stoppedMode;

    /**
     * <p>The specifications of the system cloud disk.</p>
     */
    @NameInMap("SystemDisk")
    public DescribeRCInstanceAttributeResponseBodySystemDisk systemDisk;

    @NameInMap("Tags")
    public DescribeRCInstanceAttributeResponseBodyTags tags;

    /**
     * <p>The custom data of the instance, which is a Base64-encoded string.</p>
     * <blockquote>
     * <p>If the instance does not have custom data, an empty string is returned.</p>
     * </blockquote>
     * 
     * <strong>example:</strong>
     * <p>IyEvYmluL3NoCmVjaG8gXCJIZWxsbyBXb3JsZC4gVGhlIHRpbWUgaXMgbm93ICQoZGF0ZSAtUikhXCIgfCB0ZWUgL3Jvb3QvdXNlcmRhdGFfdGVzdDA2MjB0d28udHh0</p>
     */
    @NameInMap("UserData")
    public String userData;

    /**
     * <p>The VLAN ID of the instance.</p>
     * <blockquote>
     * <p>This parameter will be deprecated soon. To improve compatibility, use other parameters instead.</p>
     * </blockquote>
     * 
     * <strong>example:</strong>
     * <p>None</p>
     */
    @NameInMap("VlanId")
    public String vlanId;

    /**
     * <p>The VPC attributes.</p>
     * 
     * <strong>if can be null:</strong>
     * <p>true</p>
     */
    @NameInMap("VpcAttributes")
    public DescribeRCInstanceAttributeResponseBodyVpcAttributes vpcAttributes;

    /**
     * <p>The zone ID.</p>
     * 
     * <strong>example:</strong>
     * <p>cn-hangzhou-b</p>
     */
    @NameInMap("ZoneId")
    public String zoneId;

    public static DescribeRCInstanceAttributeResponseBody build(java.util.Map<String, ?> map) throws Exception {
        DescribeRCInstanceAttributeResponseBody self = new DescribeRCInstanceAttributeResponseBody();
        return TeaModel.build(map, self);
    }

    public DescribeRCInstanceAttributeResponseBody setAutoRenew(Boolean autoRenew) {
        this.autoRenew = autoRenew;
        return this;
    }
    public Boolean getAutoRenew() {
        return this.autoRenew;
    }

    public DescribeRCInstanceAttributeResponseBody setClusterId(String clusterId) {
        this.clusterId = clusterId;
        return this;
    }
    public String getClusterId() {
        return this.clusterId;
    }

    public DescribeRCInstanceAttributeResponseBody setCpu(Integer cpu) {
        this.cpu = cpu;
        return this;
    }
    public Integer getCpu() {
        return this.cpu;
    }

    public DescribeRCInstanceAttributeResponseBody setCreateMode(Integer createMode) {
        this.createMode = createMode;
        return this;
    }
    public Integer getCreateMode() {
        return this.createMode;
    }

    public DescribeRCInstanceAttributeResponseBody setCreationTime(String creationTime) {
        this.creationTime = creationTime;
        return this;
    }
    public String getCreationTime() {
        return this.creationTime;
    }

    public DescribeRCInstanceAttributeResponseBody setCreditSpecification(String creditSpecification) {
        this.creditSpecification = creditSpecification;
        return this;
    }
    public String getCreditSpecification() {
        return this.creditSpecification;
    }

    public DescribeRCInstanceAttributeResponseBody setDataDisks(DescribeRCInstanceAttributeResponseBodyDataDisks dataDisks) {
        this.dataDisks = dataDisks;
        return this;
    }
    public DescribeRCInstanceAttributeResponseBodyDataDisks getDataDisks() {
        return this.dataDisks;
    }

    public DescribeRCInstanceAttributeResponseBody setDbType(String dbType) {
        this.dbType = dbType;
        return this;
    }
    public String getDbType() {
        return this.dbType;
    }

    public DescribeRCInstanceAttributeResponseBody setDedicatedHostAttribute(DescribeRCInstanceAttributeResponseBodyDedicatedHostAttribute dedicatedHostAttribute) {
        this.dedicatedHostAttribute = dedicatedHostAttribute;
        return this;
    }
    public DescribeRCInstanceAttributeResponseBodyDedicatedHostAttribute getDedicatedHostAttribute() {
        return this.dedicatedHostAttribute;
    }

    public DescribeRCInstanceAttributeResponseBody setDeletionProtection(Boolean deletionProtection) {
        this.deletionProtection = deletionProtection;
        return this;
    }
    public Boolean getDeletionProtection() {
        return this.deletionProtection;
    }

    public DescribeRCInstanceAttributeResponseBody setDeploymentSetId(String deploymentSetId) {
        this.deploymentSetId = deploymentSetId;
        return this;
    }
    public String getDeploymentSetId() {
        return this.deploymentSetId;
    }

    public DescribeRCInstanceAttributeResponseBody setDescription(String description) {
        this.description = description;
        return this;
    }
    public String getDescription() {
        return this.description;
    }

    public DescribeRCInstanceAttributeResponseBody setDiskType(String diskType) {
        this.diskType = diskType;
        return this;
    }
    public String getDiskType() {
        return this.diskType;
    }

    public DescribeRCInstanceAttributeResponseBody setEcsInstanceType(String ecsInstanceType) {
        this.ecsInstanceType = ecsInstanceType;
        return this;
    }
    public String getEcsInstanceType() {
        return this.ecsInstanceType;
    }

    public DescribeRCInstanceAttributeResponseBody setEipAddress(DescribeRCInstanceAttributeResponseBodyEipAddress eipAddress) {
        this.eipAddress = eipAddress;
        return this;
    }
    public DescribeRCInstanceAttributeResponseBodyEipAddress getEipAddress() {
        return this.eipAddress;
    }

    public DescribeRCInstanceAttributeResponseBody setEnableJumboFrame(Boolean enableJumboFrame) {
        this.enableJumboFrame = enableJumboFrame;
        return this;
    }
    public Boolean getEnableJumboFrame() {
        return this.enableJumboFrame;
    }

    public DescribeRCInstanceAttributeResponseBody setExpiredTime(String expiredTime) {
        this.expiredTime = expiredTime;
        return this;
    }
    public String getExpiredTime() {
        return this.expiredTime;
    }

    public DescribeRCInstanceAttributeResponseBody setGpu(Integer gpu) {
        this.gpu = gpu;
        return this;
    }
    public Integer getGpu() {
        return this.gpu;
    }

    public DescribeRCInstanceAttributeResponseBody setGpuTypes(String gpuTypes) {
        this.gpuTypes = gpuTypes;
        return this;
    }
    public String getGpuTypes() {
        return this.gpuTypes;
    }

    public DescribeRCInstanceAttributeResponseBody setHostName(String hostName) {
        this.hostName = hostName;
        return this;
    }
    public String getHostName() {
        return this.hostName;
    }

    public DescribeRCInstanceAttributeResponseBody setHostType(String hostType) {
        this.hostType = hostType;
        return this;
    }
    public String getHostType() {
        return this.hostType;
    }

    public DescribeRCInstanceAttributeResponseBody setImageId(String imageId) {
        this.imageId = imageId;
        return this;
    }
    public String getImageId() {
        return this.imageId;
    }

    public DescribeRCInstanceAttributeResponseBody setInnerIpAddress(DescribeRCInstanceAttributeResponseBodyInnerIpAddress innerIpAddress) {
        this.innerIpAddress = innerIpAddress;
        return this;
    }
    public DescribeRCInstanceAttributeResponseBodyInnerIpAddress getInnerIpAddress() {
        return this.innerIpAddress;
    }

    public DescribeRCInstanceAttributeResponseBody setInstanceChargeType(String instanceChargeType) {
        this.instanceChargeType = instanceChargeType;
        return this;
    }
    public String getInstanceChargeType() {
        return this.instanceChargeType;
    }

    public DescribeRCInstanceAttributeResponseBody setInstanceId(String instanceId) {
        this.instanceId = instanceId;
        return this;
    }
    public String getInstanceId() {
        return this.instanceId;
    }

    public DescribeRCInstanceAttributeResponseBody setInstanceName(String instanceName) {
        this.instanceName = instanceName;
        return this;
    }
    public String getInstanceName() {
        return this.instanceName;
    }

    public DescribeRCInstanceAttributeResponseBody setInstanceNetworkType(String instanceNetworkType) {
        this.instanceNetworkType = instanceNetworkType;
        return this;
    }
    public String getInstanceNetworkType() {
        return this.instanceNetworkType;
    }

    public DescribeRCInstanceAttributeResponseBody setInstanceType(String instanceType) {
        this.instanceType = instanceType;
        return this;
    }
    public String getInstanceType() {
        return this.instanceType;
    }

    public DescribeRCInstanceAttributeResponseBody setInternetChargeType(String internetChargeType) {
        this.internetChargeType = internetChargeType;
        return this;
    }
    public String getInternetChargeType() {
        return this.internetChargeType;
    }

    public DescribeRCInstanceAttributeResponseBody setInternetMaxBandwidthIn(Integer internetMaxBandwidthIn) {
        this.internetMaxBandwidthIn = internetMaxBandwidthIn;
        return this;
    }
    public Integer getInternetMaxBandwidthIn() {
        return this.internetMaxBandwidthIn;
    }

    public DescribeRCInstanceAttributeResponseBody setInternetMaxBandwidthOut(Integer internetMaxBandwidthOut) {
        this.internetMaxBandwidthOut = internetMaxBandwidthOut;
        return this;
    }
    public Integer getInternetMaxBandwidthOut() {
        return this.internetMaxBandwidthOut;
    }

    public DescribeRCInstanceAttributeResponseBody setIoOptimized(String ioOptimized) {
        this.ioOptimized = ioOptimized;
        return this;
    }
    public String getIoOptimized() {
        return this.ioOptimized;
    }

    public DescribeRCInstanceAttributeResponseBody setKeyPairName(String keyPairName) {
        this.keyPairName = keyPairName;
        return this;
    }
    public String getKeyPairName() {
        return this.keyPairName;
    }

    public DescribeRCInstanceAttributeResponseBody setMemory(Integer memory) {
        this.memory = memory;
        return this;
    }
    public Integer getMemory() {
        return this.memory;
    }

    public DescribeRCInstanceAttributeResponseBody setNodeType(String nodeType) {
        this.nodeType = nodeType;
        return this;
    }
    public String getNodeType() {
        return this.nodeType;
    }

    public DescribeRCInstanceAttributeResponseBody setOperationLocks(DescribeRCInstanceAttributeResponseBodyOperationLocks operationLocks) {
        this.operationLocks = operationLocks;
        return this;
    }
    public DescribeRCInstanceAttributeResponseBodyOperationLocks getOperationLocks() {
        return this.operationLocks;
    }

    public DescribeRCInstanceAttributeResponseBody setPublicIpAddress(DescribeRCInstanceAttributeResponseBodyPublicIpAddress publicIpAddress) {
        this.publicIpAddress = publicIpAddress;
        return this;
    }
    public DescribeRCInstanceAttributeResponseBodyPublicIpAddress getPublicIpAddress() {
        return this.publicIpAddress;
    }

    public DescribeRCInstanceAttributeResponseBody setRegionId(String regionId) {
        this.regionId = regionId;
        return this;
    }
    public String getRegionId() {
        return this.regionId;
    }

    public DescribeRCInstanceAttributeResponseBody setRequestId(String requestId) {
        this.requestId = requestId;
        return this;
    }
    public String getRequestId() {
        return this.requestId;
    }

    public DescribeRCInstanceAttributeResponseBody setResourceGroupId(String resourceGroupId) {
        this.resourceGroupId = resourceGroupId;
        return this;
    }
    public String getResourceGroupId() {
        return this.resourceGroupId;
    }

    public DescribeRCInstanceAttributeResponseBody setSecurityGroupIds(DescribeRCInstanceAttributeResponseBodySecurityGroupIds securityGroupIds) {
        this.securityGroupIds = securityGroupIds;
        return this;
    }
    public DescribeRCInstanceAttributeResponseBodySecurityGroupIds getSecurityGroupIds() {
        return this.securityGroupIds;
    }

    public DescribeRCInstanceAttributeResponseBody setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
        return this;
    }
    public String getSerialNumber() {
        return this.serialNumber;
    }

    public DescribeRCInstanceAttributeResponseBody setSpotStrategy(String spotStrategy) {
        this.spotStrategy = spotStrategy;
        return this;
    }
    public String getSpotStrategy() {
        return this.spotStrategy;
    }

    public DescribeRCInstanceAttributeResponseBody setStatus(String status) {
        this.status = status;
        return this;
    }
    public String getStatus() {
        return this.status;
    }

    public DescribeRCInstanceAttributeResponseBody setStoppedMode(String stoppedMode) {
        this.stoppedMode = stoppedMode;
        return this;
    }
    public String getStoppedMode() {
        return this.stoppedMode;
    }

    public DescribeRCInstanceAttributeResponseBody setSystemDisk(DescribeRCInstanceAttributeResponseBodySystemDisk systemDisk) {
        this.systemDisk = systemDisk;
        return this;
    }
    public DescribeRCInstanceAttributeResponseBodySystemDisk getSystemDisk() {
        return this.systemDisk;
    }

    public DescribeRCInstanceAttributeResponseBody setTags(DescribeRCInstanceAttributeResponseBodyTags tags) {
        this.tags = tags;
        return this;
    }
    public DescribeRCInstanceAttributeResponseBodyTags getTags() {
        return this.tags;
    }

    public DescribeRCInstanceAttributeResponseBody setUserData(String userData) {
        this.userData = userData;
        return this;
    }
    public String getUserData() {
        return this.userData;
    }

    public DescribeRCInstanceAttributeResponseBody setVlanId(String vlanId) {
        this.vlanId = vlanId;
        return this;
    }
    public String getVlanId() {
        return this.vlanId;
    }

    public DescribeRCInstanceAttributeResponseBody setVpcAttributes(DescribeRCInstanceAttributeResponseBodyVpcAttributes vpcAttributes) {
        this.vpcAttributes = vpcAttributes;
        return this;
    }
    public DescribeRCInstanceAttributeResponseBodyVpcAttributes getVpcAttributes() {
        return this.vpcAttributes;
    }

    public DescribeRCInstanceAttributeResponseBody setZoneId(String zoneId) {
        this.zoneId = zoneId;
        return this;
    }
    public String getZoneId() {
        return this.zoneId;
    }

    public static class DescribeRCInstanceAttributeResponseBodyDataDisksDataDisk extends TeaModel {
        @NameInMap("Category")
        public String category;

        @NameInMap("DeleteWithInstance")
        public Boolean deleteWithInstance;

        /**
         * <strong>example:</strong>
         * <p>/dev/xvdb</p>
         */
        @NameInMap("Device")
        public String device;

        @NameInMap("Encrypted")
        public String encrypted;

        @NameInMap("PerformanceLevel")
        public String performanceLevel;

        @NameInMap("Size")
        public Long size;

        /**
         * <strong>example:</strong>
         * <p>rcds-bp18um4r4f2fve24**</p>
         */
        @NameInMap("SnapshotId")
        public String snapshotId;

        public static DescribeRCInstanceAttributeResponseBodyDataDisksDataDisk build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCInstanceAttributeResponseBodyDataDisksDataDisk self = new DescribeRCInstanceAttributeResponseBodyDataDisksDataDisk();
            return TeaModel.build(map, self);
        }

        public DescribeRCInstanceAttributeResponseBodyDataDisksDataDisk setCategory(String category) {
            this.category = category;
            return this;
        }
        public String getCategory() {
            return this.category;
        }

        public DescribeRCInstanceAttributeResponseBodyDataDisksDataDisk setDeleteWithInstance(Boolean deleteWithInstance) {
            this.deleteWithInstance = deleteWithInstance;
            return this;
        }
        public Boolean getDeleteWithInstance() {
            return this.deleteWithInstance;
        }

        public DescribeRCInstanceAttributeResponseBodyDataDisksDataDisk setDevice(String device) {
            this.device = device;
            return this;
        }
        public String getDevice() {
            return this.device;
        }

        public DescribeRCInstanceAttributeResponseBodyDataDisksDataDisk setEncrypted(String encrypted) {
            this.encrypted = encrypted;
            return this;
        }
        public String getEncrypted() {
            return this.encrypted;
        }

        public DescribeRCInstanceAttributeResponseBodyDataDisksDataDisk setPerformanceLevel(String performanceLevel) {
            this.performanceLevel = performanceLevel;
            return this;
        }
        public String getPerformanceLevel() {
            return this.performanceLevel;
        }

        public DescribeRCInstanceAttributeResponseBodyDataDisksDataDisk setSize(Long size) {
            this.size = size;
            return this;
        }
        public Long getSize() {
            return this.size;
        }

        public DescribeRCInstanceAttributeResponseBodyDataDisksDataDisk setSnapshotId(String snapshotId) {
            this.snapshotId = snapshotId;
            return this;
        }
        public String getSnapshotId() {
            return this.snapshotId;
        }

    }

    public static class DescribeRCInstanceAttributeResponseBodyDataDisks extends TeaModel {
        @NameInMap("DataDisk")
        public java.util.List<DescribeRCInstanceAttributeResponseBodyDataDisksDataDisk> dataDisk;

        public static DescribeRCInstanceAttributeResponseBodyDataDisks build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCInstanceAttributeResponseBodyDataDisks self = new DescribeRCInstanceAttributeResponseBodyDataDisks();
            return TeaModel.build(map, self);
        }

        public DescribeRCInstanceAttributeResponseBodyDataDisks setDataDisk(java.util.List<DescribeRCInstanceAttributeResponseBodyDataDisksDataDisk> dataDisk) {
            this.dataDisk = dataDisk;
            return this;
        }
        public java.util.List<DescribeRCInstanceAttributeResponseBodyDataDisksDataDisk> getDataDisk() {
            return this.dataDisk;
        }

    }

    public static class DescribeRCInstanceAttributeResponseBodyDedicatedHostAttribute extends TeaModel {
        /**
         * <p>The ID of the dedicated host.</p>
         * 
         * <strong>example:</strong>
         * <p>None</p>
         */
        @NameInMap("DedicatedHostId")
        public String dedicatedHostId;

        /**
         * <p>The name of the dedicated host.</p>
         * 
         * <strong>example:</strong>
         * <p>None</p>
         */
        @NameInMap("DedicatedHostName")
        public String dedicatedHostName;

        public static DescribeRCInstanceAttributeResponseBodyDedicatedHostAttribute build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCInstanceAttributeResponseBodyDedicatedHostAttribute self = new DescribeRCInstanceAttributeResponseBodyDedicatedHostAttribute();
            return TeaModel.build(map, self);
        }

        public DescribeRCInstanceAttributeResponseBodyDedicatedHostAttribute setDedicatedHostId(String dedicatedHostId) {
            this.dedicatedHostId = dedicatedHostId;
            return this;
        }
        public String getDedicatedHostId() {
            return this.dedicatedHostId;
        }

        public DescribeRCInstanceAttributeResponseBodyDedicatedHostAttribute setDedicatedHostName(String dedicatedHostName) {
            this.dedicatedHostName = dedicatedHostName;
            return this;
        }
        public String getDedicatedHostName() {
            return this.dedicatedHostName;
        }

    }

    public static class DescribeRCInstanceAttributeResponseBodyEipAddress extends TeaModel {
        /**
         * <p>The ID of the EIP.</p>
         * 
         * <strong>example:</strong>
         * <p>eip-bp14k3rz6cbg6zxbe****</p>
         */
        @NameInMap("AllocationId")
        public String allocationId;

        /**
         * <p>The Internet bandwidth throttling of the EIP. Unit: Mbit/s.</p>
         * 
         * <strong>example:</strong>
         * <p>5</p>
         */
        @NameInMap("Bandwidth")
        public Integer bandwidth;

        /**
         * <p>The billing method for network usage of the instance. Valid values:</p>
         * <ul>
         * <li><strong>paybytraffic</strong>: pay-by-traffic.</li>
         * <li><strong>paybybandwidth</strong>: pay-by-bandwidth.<blockquote>
         * <p>In <strong>pay-by-traffic</strong> mode, the peak inbound and outbound bandwidth values are upper limits and are not guaranteed. During resource contention, the peak bandwidth may be limited. If your business requires guaranteed bandwidth, use the <strong>pay-by-bandwidth</strong> mode.</p>
         * </blockquote>
         * </li>
         * </ul>
         * 
         * <strong>example:</strong>
         * <p>paybytraffic</p>
         */
        @NameInMap("InternetChargeType")
        public String internetChargeType;

        /**
         * <p>The EIP address.</p>
         * 
         * <strong>example:</strong>
         * <p>8.147.XXX.XXX</p>
         */
        @NameInMap("IpAddress")
        public String ipAddress;

        public static DescribeRCInstanceAttributeResponseBodyEipAddress build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCInstanceAttributeResponseBodyEipAddress self = new DescribeRCInstanceAttributeResponseBodyEipAddress();
            return TeaModel.build(map, self);
        }

        public DescribeRCInstanceAttributeResponseBodyEipAddress setAllocationId(String allocationId) {
            this.allocationId = allocationId;
            return this;
        }
        public String getAllocationId() {
            return this.allocationId;
        }

        public DescribeRCInstanceAttributeResponseBodyEipAddress setBandwidth(Integer bandwidth) {
            this.bandwidth = bandwidth;
            return this;
        }
        public Integer getBandwidth() {
            return this.bandwidth;
        }

        public DescribeRCInstanceAttributeResponseBodyEipAddress setInternetChargeType(String internetChargeType) {
            this.internetChargeType = internetChargeType;
            return this;
        }
        public String getInternetChargeType() {
            return this.internetChargeType;
        }

        public DescribeRCInstanceAttributeResponseBodyEipAddress setIpAddress(String ipAddress) {
            this.ipAddress = ipAddress;
            return this;
        }
        public String getIpAddress() {
            return this.ipAddress;
        }

    }

    public static class DescribeRCInstanceAttributeResponseBodyInnerIpAddress extends TeaModel {
        @NameInMap("IpAddress")
        public java.util.List<String> ipAddress;

        public static DescribeRCInstanceAttributeResponseBodyInnerIpAddress build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCInstanceAttributeResponseBodyInnerIpAddress self = new DescribeRCInstanceAttributeResponseBodyInnerIpAddress();
            return TeaModel.build(map, self);
        }

        public DescribeRCInstanceAttributeResponseBodyInnerIpAddress setIpAddress(java.util.List<String> ipAddress) {
            this.ipAddress = ipAddress;
            return this;
        }
        public java.util.List<String> getIpAddress() {
            return this.ipAddress;
        }

    }

    public static class DescribeRCInstanceAttributeResponseBodyOperationLocksLockReason extends TeaModel {
        @NameInMap("LockReason")
        public String lockReason;

        public static DescribeRCInstanceAttributeResponseBodyOperationLocksLockReason build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCInstanceAttributeResponseBodyOperationLocksLockReason self = new DescribeRCInstanceAttributeResponseBodyOperationLocksLockReason();
            return TeaModel.build(map, self);
        }

        public DescribeRCInstanceAttributeResponseBodyOperationLocksLockReason setLockReason(String lockReason) {
            this.lockReason = lockReason;
            return this;
        }
        public String getLockReason() {
            return this.lockReason;
        }

    }

    public static class DescribeRCInstanceAttributeResponseBodyOperationLocks extends TeaModel {
        @NameInMap("LockReason")
        public java.util.List<DescribeRCInstanceAttributeResponseBodyOperationLocksLockReason> lockReason;

        public static DescribeRCInstanceAttributeResponseBodyOperationLocks build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCInstanceAttributeResponseBodyOperationLocks self = new DescribeRCInstanceAttributeResponseBodyOperationLocks();
            return TeaModel.build(map, self);
        }

        public DescribeRCInstanceAttributeResponseBodyOperationLocks setLockReason(java.util.List<DescribeRCInstanceAttributeResponseBodyOperationLocksLockReason> lockReason) {
            this.lockReason = lockReason;
            return this;
        }
        public java.util.List<DescribeRCInstanceAttributeResponseBodyOperationLocksLockReason> getLockReason() {
            return this.lockReason;
        }

    }

    public static class DescribeRCInstanceAttributeResponseBodyPublicIpAddress extends TeaModel {
        @NameInMap("IpAddress")
        public java.util.List<String> ipAddress;

        public static DescribeRCInstanceAttributeResponseBodyPublicIpAddress build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCInstanceAttributeResponseBodyPublicIpAddress self = new DescribeRCInstanceAttributeResponseBodyPublicIpAddress();
            return TeaModel.build(map, self);
        }

        public DescribeRCInstanceAttributeResponseBodyPublicIpAddress setIpAddress(java.util.List<String> ipAddress) {
            this.ipAddress = ipAddress;
            return this;
        }
        public java.util.List<String> getIpAddress() {
            return this.ipAddress;
        }

    }

    public static class DescribeRCInstanceAttributeResponseBodySecurityGroupIds extends TeaModel {
        @NameInMap("SecurityGroupId")
        public java.util.List<String> securityGroupId;

        public static DescribeRCInstanceAttributeResponseBodySecurityGroupIds build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCInstanceAttributeResponseBodySecurityGroupIds self = new DescribeRCInstanceAttributeResponseBodySecurityGroupIds();
            return TeaModel.build(map, self);
        }

        public DescribeRCInstanceAttributeResponseBodySecurityGroupIds setSecurityGroupId(java.util.List<String> securityGroupId) {
            this.securityGroupId = securityGroupId;
            return this;
        }
        public java.util.List<String> getSecurityGroupId() {
            return this.securityGroupId;
        }

    }

    public static class DescribeRCInstanceAttributeResponseBodySystemDisk extends TeaModel {
        /**
         * <p>A reserved parameter.</p>
         * 
         * <strong>example:</strong>
         * <p>None</p>
         */
        @NameInMap("DeleteWithInstance")
        public Boolean deleteWithInstance;

        /**
         * <p>Indicates whether the cloud disk is encrypted. Valid values:</p>
         * <ul>
         * <li><strong>true</strong>: Yes.</li>
         * <li><strong>false</strong>: No.</li>
         * </ul>
         * 
         * <strong>example:</strong>
         * <p>false</p>
         */
        @NameInMap("Encrypted")
        public String encrypted;

        /**
         * <p>The category of the system cloud disk. Valid values:</p>
         * <ul>
         * <li><strong>cloud_efficiency</strong>: ultra disk.</li>
         * <li><strong>cloud_ssd</strong>: standard SSD.</li>
         * <li><strong>cloud_essd</strong>: ESSD.</li>
         * <li><strong>cloud_auto</strong>: premium performance disk.</li>
         * </ul>
         * 
         * <strong>example:</strong>
         * <p>cloud_essd</p>
         */
        @NameInMap("SystemDiskCategory")
        public String systemDiskCategory;

        /**
         * <p>The performance level of the system cloud disk when it is an ESSD. Valid values:</p>
         * <ul>
         * <li><strong>PL0</strong></li>
         * <li><strong>PL1</strong></li>
         * <li><strong>PL2</strong></li>
         * <li><strong>PL3</strong></li>
         * </ul>
         * 
         * <strong>example:</strong>
         * <p>PL1</p>
         */
        @NameInMap("SystemDiskPerformanceLevel")
        public String systemDiskPerformanceLevel;

        /**
         * <p>The size of the system cloud disk. Unit: GiB.</p>
         * 
         * <strong>example:</strong>
         * <p>40</p>
         */
        @NameInMap("SystemDiskSize")
        public Long systemDiskSize;

        public static DescribeRCInstanceAttributeResponseBodySystemDisk build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCInstanceAttributeResponseBodySystemDisk self = new DescribeRCInstanceAttributeResponseBodySystemDisk();
            return TeaModel.build(map, self);
        }

        public DescribeRCInstanceAttributeResponseBodySystemDisk setDeleteWithInstance(Boolean deleteWithInstance) {
            this.deleteWithInstance = deleteWithInstance;
            return this;
        }
        public Boolean getDeleteWithInstance() {
            return this.deleteWithInstance;
        }

        public DescribeRCInstanceAttributeResponseBodySystemDisk setEncrypted(String encrypted) {
            this.encrypted = encrypted;
            return this;
        }
        public String getEncrypted() {
            return this.encrypted;
        }

        public DescribeRCInstanceAttributeResponseBodySystemDisk setSystemDiskCategory(String systemDiskCategory) {
            this.systemDiskCategory = systemDiskCategory;
            return this;
        }
        public String getSystemDiskCategory() {
            return this.systemDiskCategory;
        }

        public DescribeRCInstanceAttributeResponseBodySystemDisk setSystemDiskPerformanceLevel(String systemDiskPerformanceLevel) {
            this.systemDiskPerformanceLevel = systemDiskPerformanceLevel;
            return this;
        }
        public String getSystemDiskPerformanceLevel() {
            return this.systemDiskPerformanceLevel;
        }

        public DescribeRCInstanceAttributeResponseBodySystemDisk setSystemDiskSize(Long systemDiskSize) {
            this.systemDiskSize = systemDiskSize;
            return this;
        }
        public Long getSystemDiskSize() {
            return this.systemDiskSize;
        }

    }

    public static class DescribeRCInstanceAttributeResponseBodyTagsTag extends TeaModel {
        @NameInMap("ResourceId")
        public String resourceId;

        @NameInMap("ResourceType")
        public String resourceType;

        @NameInMap("TagKey")
        public String tagKey;

        @NameInMap("TagValue")
        public String tagValue;

        public static DescribeRCInstanceAttributeResponseBodyTagsTag build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCInstanceAttributeResponseBodyTagsTag self = new DescribeRCInstanceAttributeResponseBodyTagsTag();
            return TeaModel.build(map, self);
        }

        public DescribeRCInstanceAttributeResponseBodyTagsTag setResourceId(String resourceId) {
            this.resourceId = resourceId;
            return this;
        }
        public String getResourceId() {
            return this.resourceId;
        }

        public DescribeRCInstanceAttributeResponseBodyTagsTag setResourceType(String resourceType) {
            this.resourceType = resourceType;
            return this;
        }
        public String getResourceType() {
            return this.resourceType;
        }

        public DescribeRCInstanceAttributeResponseBodyTagsTag setTagKey(String tagKey) {
            this.tagKey = tagKey;
            return this;
        }
        public String getTagKey() {
            return this.tagKey;
        }

        public DescribeRCInstanceAttributeResponseBodyTagsTag setTagValue(String tagValue) {
            this.tagValue = tagValue;
            return this;
        }
        public String getTagValue() {
            return this.tagValue;
        }

    }

    public static class DescribeRCInstanceAttributeResponseBodyTags extends TeaModel {
        @NameInMap("Tag")
        public java.util.List<DescribeRCInstanceAttributeResponseBodyTagsTag> tag;

        public static DescribeRCInstanceAttributeResponseBodyTags build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCInstanceAttributeResponseBodyTags self = new DescribeRCInstanceAttributeResponseBodyTags();
            return TeaModel.build(map, self);
        }

        public DescribeRCInstanceAttributeResponseBodyTags setTag(java.util.List<DescribeRCInstanceAttributeResponseBodyTagsTag> tag) {
            this.tag = tag;
            return this;
        }
        public java.util.List<DescribeRCInstanceAttributeResponseBodyTagsTag> getTag() {
            return this.tag;
        }

    }

    public static class DescribeRCInstanceAttributeResponseBodyVpcAttributesPrivateIpAddress extends TeaModel {
        @NameInMap("IpAddress")
        public java.util.List<String> ipAddress;

        public static DescribeRCInstanceAttributeResponseBodyVpcAttributesPrivateIpAddress build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCInstanceAttributeResponseBodyVpcAttributesPrivateIpAddress self = new DescribeRCInstanceAttributeResponseBodyVpcAttributesPrivateIpAddress();
            return TeaModel.build(map, self);
        }

        public DescribeRCInstanceAttributeResponseBodyVpcAttributesPrivateIpAddress setIpAddress(java.util.List<String> ipAddress) {
            this.ipAddress = ipAddress;
            return this;
        }
        public java.util.List<String> getIpAddress() {
            return this.ipAddress;
        }

    }

    public static class DescribeRCInstanceAttributeResponseBodyVpcAttributes extends TeaModel {
        /**
         * <p>The IP address of the cloud service, which is used for network connectivity between cloud services in a VPC.</p>
         * 
         * <strong>example:</strong>
         * <p>None</p>
         */
        @NameInMap("NatIpAddress")
        public String natIpAddress;

        @NameInMap("PrivateIpAddress")
        public DescribeRCInstanceAttributeResponseBodyVpcAttributesPrivateIpAddress privateIpAddress;

        /**
         * <p>The vSwitch ID.</p>
         * 
         * <strong>example:</strong>
         * <p>vsw-bp1nt15muovrc5qdj****</p>
         */
        @NameInMap("VSwitchId")
        public String vSwitchId;

        /**
         * <p>The VPC ID.</p>
         * 
         * <strong>example:</strong>
         * <p>vpc-2zeu747v4765aw2id****</p>
         */
        @NameInMap("VpcId")
        public String vpcId;

        public static DescribeRCInstanceAttributeResponseBodyVpcAttributes build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCInstanceAttributeResponseBodyVpcAttributes self = new DescribeRCInstanceAttributeResponseBodyVpcAttributes();
            return TeaModel.build(map, self);
        }

        public DescribeRCInstanceAttributeResponseBodyVpcAttributes setNatIpAddress(String natIpAddress) {
            this.natIpAddress = natIpAddress;
            return this;
        }
        public String getNatIpAddress() {
            return this.natIpAddress;
        }

        public DescribeRCInstanceAttributeResponseBodyVpcAttributes setPrivateIpAddress(DescribeRCInstanceAttributeResponseBodyVpcAttributesPrivateIpAddress privateIpAddress) {
            this.privateIpAddress = privateIpAddress;
            return this;
        }
        public DescribeRCInstanceAttributeResponseBodyVpcAttributesPrivateIpAddress getPrivateIpAddress() {
            return this.privateIpAddress;
        }

        public DescribeRCInstanceAttributeResponseBodyVpcAttributes setVSwitchId(String vSwitchId) {
            this.vSwitchId = vSwitchId;
            return this;
        }
        public String getVSwitchId() {
            return this.vSwitchId;
        }

        public DescribeRCInstanceAttributeResponseBodyVpcAttributes setVpcId(String vpcId) {
            this.vpcId = vpcId;
            return this;
        }
        public String getVpcId() {
            return this.vpcId;
        }

    }

}
