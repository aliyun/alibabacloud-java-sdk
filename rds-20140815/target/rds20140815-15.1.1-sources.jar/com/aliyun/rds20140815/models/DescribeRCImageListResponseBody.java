// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.rds20140815.models;

import com.aliyun.tea.*;

public class DescribeRCImageListResponseBody extends TeaModel {
    /**
     * <p>The image information.</p>
     */
    @NameInMap("Images")
    public java.util.List<DescribeRCImageListResponseBodyImages> images;

    /**
     * <p>The page number.</p>
     * 
     * <strong>example:</strong>
     * <p>1</p>
     */
    @NameInMap("PageNumber")
    public Integer pageNumber;

    /**
     * <p>The number of entries per page.</p>
     * 
     * <strong>example:</strong>
     * <p>5</p>
     */
    @NameInMap("PageSize")
    public Integer pageSize;

    /**
     * <p>The region ID.</p>
     * 
     * <strong>example:</strong>
     * <p>cn-hangzhou</p>
     */
    @NameInMap("RegionId")
    public String regionId;

    /**
     * <p>The request ID.</p>
     * 
     * <strong>example:</strong>
     * <p>2553A660-E4EB-4AF4-A402-8AFF70A49143</p>
     */
    @NameInMap("RequestId")
    public String requestId;

    /**
     * <p>The total number of images.</p>
     * 
     * <strong>example:</strong>
     * <p>2</p>
     */
    @NameInMap("TotalCount")
    public Integer totalCount;

    public static DescribeRCImageListResponseBody build(java.util.Map<String, ?> map) throws Exception {
        DescribeRCImageListResponseBody self = new DescribeRCImageListResponseBody();
        return TeaModel.build(map, self);
    }

    public DescribeRCImageListResponseBody setImages(java.util.List<DescribeRCImageListResponseBodyImages> images) {
        this.images = images;
        return this;
    }
    public java.util.List<DescribeRCImageListResponseBodyImages> getImages() {
        return this.images;
    }

    public DescribeRCImageListResponseBody setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
        return this;
    }
    public Integer getPageNumber() {
        return this.pageNumber;
    }

    public DescribeRCImageListResponseBody setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
        return this;
    }
    public Integer getPageSize() {
        return this.pageSize;
    }

    public DescribeRCImageListResponseBody setRegionId(String regionId) {
        this.regionId = regionId;
        return this;
    }
    public String getRegionId() {
        return this.regionId;
    }

    public DescribeRCImageListResponseBody setRequestId(String requestId) {
        this.requestId = requestId;
        return this;
    }
    public String getRequestId() {
        return this.requestId;
    }

    public DescribeRCImageListResponseBody setTotalCount(Integer totalCount) {
        this.totalCount = totalCount;
        return this;
    }
    public Integer getTotalCount() {
        return this.totalCount;
    }

    public static class DescribeRCImageListResponseBodyImagesDiskDeviceMappings extends TeaModel {
        /**
         * <p>The device information of the cloud disk, such as <code>/dev/xvdb</code>.</p>
         * 
         * <strong>example:</strong>
         * <p>/dev/xvdb</p>
         */
        @NameInMap("Device")
        public String device;

        /**
         * <p>The size of the cloud disk. Unit: GiB.</p>
         * 
         * <strong>example:</strong>
         * <p>40</p>
         */
        @NameInMap("Size")
        public String size;

        /**
         * <p>The attribute of the cloud disk. Valid values:</p>
         * <ul>
         * <li><strong>system</strong>: System cloud disk.</li>
         * <li><strong>data</strong>: Data cloud disk.</li>
         * </ul>
         * 
         * <strong>example:</strong>
         * <p>system</p>
         */
        @NameInMap("Type")
        public String type;

        public static DescribeRCImageListResponseBodyImagesDiskDeviceMappings build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCImageListResponseBodyImagesDiskDeviceMappings self = new DescribeRCImageListResponseBodyImagesDiskDeviceMappings();
            return TeaModel.build(map, self);
        }

        public DescribeRCImageListResponseBodyImagesDiskDeviceMappings setDevice(String device) {
            this.device = device;
            return this;
        }
        public String getDevice() {
            return this.device;
        }

        public DescribeRCImageListResponseBodyImagesDiskDeviceMappings setSize(String size) {
            this.size = size;
            return this;
        }
        public String getSize() {
            return this.size;
        }

        public DescribeRCImageListResponseBodyImagesDiskDeviceMappings setType(String type) {
            this.type = type;
            return this;
        }
        public String getType() {
            return this.type;
        }

    }

    public static class DescribeRCImageListResponseBodyImages extends TeaModel {
        /**
         * <p>The system architecture of the image. Valid values:</p>
         * <ul>
         * <li>x86_64</li>
         * <li>arm64</li>
         * </ul>
         * 
         * <strong>example:</strong>
         * <p>x86_64</p>
         */
        @NameInMap("Architecture")
        public String architecture;

        /**
         * <p>The creation time of the image.</p>
         * 
         * <strong>example:</strong>
         * <p>2024-04-25T02:17:40Z</p>
         */
        @NameInMap("CreationTime")
        public String creationTime;

        /**
         * <p>The description of the image.</p>
         * 
         * <strong>example:</strong>
         * <p>test</p>
         */
        @NameInMap("Description")
        public String description;

        /**
         * <p>The mappings between cloud disks and snapshots included in the image.</p>
         */
        @NameInMap("DiskDeviceMappings")
        public java.util.List<DescribeRCImageListResponseBodyImagesDiskDeviceMappings> diskDeviceMappings;

        /**
         * <p>The image ID.</p>
         * 
         * <strong>example:</strong>
         * <p>m-2oqiu973jwcxe****</p>
         */
        @NameInMap("ImageId")
        public String imageId;

        /**
         * <p>The image name.</p>
         * 
         * <strong>example:</strong>
         * <p>Created_from_i-2zeh17y17sz677x****</p>
         */
        @NameInMap("ImageName")
        public String imageName;

        /**
         * <p>The image version.</p>
         * 
         * <strong>example:</strong>
         * <p>2</p>
         */
        @NameInMap("ImageVersion")
        public String imageVersion;

        /**
         * <p>Indicates whether the image is public. Public images include public images provided by Alibaba Cloud and custom images that you have published as community images. Valid values:</p>
         * <ul>
         * <li><strong>true</strong>: The image is public.</li>
         * <li><strong>false</strong>: The image is not public.</li>
         * </ul>
         * 
         * <strong>example:</strong>
         * <p>false</p>
         */
        @NameInMap("IsPublic")
        public Boolean isPublic;

        /**
         * <p>Indicates whether the image supports RDS Custom instances. Valid values:</p>
         * <ul>
         * <li><strong>true</strong>: Yes.</li>
         * <li><strong>false</strong>: No.</li>
         * </ul>
         * 
         * <strong>example:</strong>
         * <p>true</p>
         */
        @NameInMap("IsSupportRdsCustom")
        public Boolean isSupportRdsCustom;

        /**
         * <p>The Chinese display name of the operating system.</p>
         * 
         * <strong>example:</strong>
         * <p>Alibaba Cloud Linux  2.1903 LTS 64位 快速启动版</p>
         */
        @NameInMap("OSName")
        public String OSName;

        /**
         * <p>The English display name of the operating system.</p>
         * 
         * <strong>example:</strong>
         * <p>Alibaba Cloud Linux  2.1903 LTS 64 bit Quick Boot</p>
         */
        @NameInMap("OSNameEn")
        public String OSNameEn;

        /**
         * <p>The operating system type. Valid values:</p>
         * <ul>
         * <li><strong>windows</strong></li>
         * <li><strong>linux</strong></li>
         * </ul>
         * 
         * <strong>example:</strong>
         * <p>linux</p>
         */
        @NameInMap("OSType")
        public String OSType;

        /**
         * <p>The operating system platform.</p>
         * 
         * <strong>example:</strong>
         * <p>Aliyun</p>
         */
        @NameInMap("Platform")
        public String platform;

        /**
         * <p>The size of the image. Unit: GiB.</p>
         * 
         * <strong>example:</strong>
         * <p>40</p>
         */
        @NameInMap("Size")
        public Long size;

        /**
         * <p>The status of the image. Valid values:</p>
         * <ul>
         * <li><strong>UnAvailable</strong>: The image is unavailable.</li>
         * <li><strong>Available</strong>: The image is available.</li>
         * <li><strong>Creating</strong>: The image is being created.</li>
         * <li><strong>CreateFailed</strong>: The image failed to be created.</li>
         * </ul>
         * 
         * <strong>example:</strong>
         * <p>Available</p>
         */
        @NameInMap("Status")
        public String status;

        /**
         * <p>Indicates whether the image is used by RDS Custom instances. Valid values:</p>
         * <ul>
         * <li><strong>instance</strong>: One or more RDS Custom instances are created.</li>
         * <li><strong>none</strong>: No RDS Custom instances are created.</li>
         * </ul>
         * 
         * <strong>example:</strong>
         * <p>instance</p>
         */
        @NameInMap("Usage")
        public String usage;

        public static DescribeRCImageListResponseBodyImages build(java.util.Map<String, ?> map) throws Exception {
            DescribeRCImageListResponseBodyImages self = new DescribeRCImageListResponseBodyImages();
            return TeaModel.build(map, self);
        }

        public DescribeRCImageListResponseBodyImages setArchitecture(String architecture) {
            this.architecture = architecture;
            return this;
        }
        public String getArchitecture() {
            return this.architecture;
        }

        public DescribeRCImageListResponseBodyImages setCreationTime(String creationTime) {
            this.creationTime = creationTime;
            return this;
        }
        public String getCreationTime() {
            return this.creationTime;
        }

        public DescribeRCImageListResponseBodyImages setDescription(String description) {
            this.description = description;
            return this;
        }
        public String getDescription() {
            return this.description;
        }

        public DescribeRCImageListResponseBodyImages setDiskDeviceMappings(java.util.List<DescribeRCImageListResponseBodyImagesDiskDeviceMappings> diskDeviceMappings) {
            this.diskDeviceMappings = diskDeviceMappings;
            return this;
        }
        public java.util.List<DescribeRCImageListResponseBodyImagesDiskDeviceMappings> getDiskDeviceMappings() {
            return this.diskDeviceMappings;
        }

        public DescribeRCImageListResponseBodyImages setImageId(String imageId) {
            this.imageId = imageId;
            return this;
        }
        public String getImageId() {
            return this.imageId;
        }

        public DescribeRCImageListResponseBodyImages setImageName(String imageName) {
            this.imageName = imageName;
            return this;
        }
        public String getImageName() {
            return this.imageName;
        }

        public DescribeRCImageListResponseBodyImages setImageVersion(String imageVersion) {
            this.imageVersion = imageVersion;
            return this;
        }
        public String getImageVersion() {
            return this.imageVersion;
        }

        public DescribeRCImageListResponseBodyImages setIsPublic(Boolean isPublic) {
            this.isPublic = isPublic;
            return this;
        }
        public Boolean getIsPublic() {
            return this.isPublic;
        }

        public DescribeRCImageListResponseBodyImages setIsSupportRdsCustom(Boolean isSupportRdsCustom) {
            this.isSupportRdsCustom = isSupportRdsCustom;
            return this;
        }
        public Boolean getIsSupportRdsCustom() {
            return this.isSupportRdsCustom;
        }

        public DescribeRCImageListResponseBodyImages setOSName(String OSName) {
            this.OSName = OSName;
            return this;
        }
        public String getOSName() {
            return this.OSName;
        }

        public DescribeRCImageListResponseBodyImages setOSNameEn(String OSNameEn) {
            this.OSNameEn = OSNameEn;
            return this;
        }
        public String getOSNameEn() {
            return this.OSNameEn;
        }

        public DescribeRCImageListResponseBodyImages setOSType(String OSType) {
            this.OSType = OSType;
            return this;
        }
        public String getOSType() {
            return this.OSType;
        }

        public DescribeRCImageListResponseBodyImages setPlatform(String platform) {
            this.platform = platform;
            return this;
        }
        public String getPlatform() {
            return this.platform;
        }

        public DescribeRCImageListResponseBodyImages setSize(Long size) {
            this.size = size;
            return this;
        }
        public Long getSize() {
            return this.size;
        }

        public DescribeRCImageListResponseBodyImages setStatus(String status) {
            this.status = status;
            return this;
        }
        public String getStatus() {
            return this.status;
        }

        public DescribeRCImageListResponseBodyImages setUsage(String usage) {
            this.usage = usage;
            return this;
        }
        public String getUsage() {
            return this.usage;
        }

    }

}
