// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.rds20140815.models;

import com.aliyun.tea.*;

public class DescribeDBProxyResponseBody extends TeaModel {
    @NameInMap("DBProxyAVZones")
    public DescribeDBProxyResponseBodyDBProxyAVZones DBProxyAVZones;

    @NameInMap("DBProxyConnectStringItems")
    public DescribeDBProxyResponseBodyDBProxyConnectStringItems DBProxyConnectStringItems;

    /**
     * <p>This is an internal parameter and can be ignored.</p>
     * 
     * <strong>example:</strong>
     * <p>normal</p>
     */
    @NameInMap("DBProxyEngineType")
    public String DBProxyEngineType;

    /**
     * <p>The current minor version of the proxy instance.</p>
     * 
     * <strong>example:</strong>
     * <p>1.13.11</p>
     */
    @NameInMap("DBProxyInstanceCurrentMinorVersion")
    public String DBProxyInstanceCurrentMinorVersion;

    /**
     * <p>The latest minor version of the proxy instance.</p>
     * 
     * <strong>example:</strong>
     * <p>1.13.12</p>
     */
    @NameInMap("DBProxyInstanceLatestMinorVersion")
    public String DBProxyInstanceLatestMinorVersion;

    /**
     * <strong>example:</strong>
     * <p>2.25.9</p>
     */
    @NameInMap("DBProxyInstanceMinorVersions")
    public DescribeDBProxyResponseBodyDBProxyInstanceMinorVersions DBProxyInstanceMinorVersions;

    /**
     * <p>The name of the proxy instance.</p>
     * 
     * <strong>example:</strong>
     * <p>gos787jog2wk0ye1****</p>
     */
    @NameInMap("DBProxyInstanceName")
    public String DBProxyInstanceName;

    /**
     * <p>The number of enabled proxy instances.</p>
     * 
     * <strong>example:</strong>
     * <p>1</p>
     */
    @NameInMap("DBProxyInstanceNum")
    public Integer DBProxyInstanceNum;

    /**
     * <p>This parameter is supported only by ApsaraDB RDS for PostgreSQL. It indicates the actual specifications of the proxy instance.</p>
     * <p>Format: <code>CPU/Memory</code>.</p>
     * <p>Example: 4/8 indicates 4 CPU cores and 8 GB of memory.</p>
     * 
     * <strong>example:</strong>
     * <p>4/8</p>
     */
    @NameInMap("DBProxyInstanceSize")
    public String DBProxyInstanceSize;

    /**
     * <p>The running status of the proxy instance. Valid values:</p>
     * <ul>
     * <li>DBInstanceClassChanging: The specifications are being changed.</li>
     * <li>Creating: The instance is being created.</li>
     * <li>Running: The instance is running.</li>
     * <li>Deleting: The instance is being deleted.</li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>Running</p>
     */
    @NameInMap("DBProxyInstanceStatus")
    public String DBProxyInstanceStatus;

    /**
     * <p>The type of the proxy service. Valid values:</p>
     * <ul>
     * <li>1: shared proxy</li>
     * <li>2: dedicated proxy</li>
     * <li>3: general-purpose database proxy</li>
     * </ul>
     * <blockquote>
     * <p>ApsaraDB RDS for PostgreSQL does not support shared proxies.</p>
     * </blockquote>
     * 
     * <strong>example:</strong>
     * <p>2</p>
     */
    @NameInMap("DBProxyInstanceType")
    public String DBProxyInstanceType;

    /**
     * <p>This is an internal parameter and can be ignored.</p>
     * 
     * <strong>example:</strong>
     * <p>18</p>
     */
    @NameInMap("DBProxyKindCode")
    public String DBProxyKindCode;

    @NameInMap("DBProxyNodes")
    public DescribeDBProxyResponseBodyDBProxyNodes DBProxyNodes;

    /**
     * <p>The status of connection persistence. Valid values:</p>
     * <ul>
     * <li><strong>Enabled</strong>: enabled</li>
     * <li><strong>Disabled</strong>: disabled</li>
     * <li><strong>Unsupported</strong>: The instance does not support connection persistence.</li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>Disabled</p>
     */
    @NameInMap("DBProxyPersistentConnectionStatus")
    public String DBProxyPersistentConnectionStatus;

    /**
     * <p>The status of the database proxy feature. Valid values:</p>
     * <ul>
     * <li>Shutdown: disabled</li>
     * <li>Startup: enabled</li>
     * </ul>
     * 
     * <strong>example:</strong>
     * <p>Startup</p>
     */
    @NameInMap("DBProxyServiceStatus")
    public String DBProxyServiceStatus;

    @NameInMap("DbProxyEndpointItems")
    public DescribeDBProxyResponseBodyDbProxyEndpointItems dbProxyEndpointItems;

    /**
     * <p>The ID of the request.</p>
     * 
     * <strong>example:</strong>
     * <p>909A69EE-71C8-4417-A0B9-FF085407E1E3</p>
     */
    @NameInMap("RequestId")
    public String requestId;

    /**
     * <p>The ID of the resource group.</p>
     * 
     * <strong>example:</strong>
     * <p>rg-acfmy****</p>
     */
    @NameInMap("ResourceGroupId")
    public String resourceGroupId;

    public static DescribeDBProxyResponseBody build(java.util.Map<String, ?> map) throws Exception {
        DescribeDBProxyResponseBody self = new DescribeDBProxyResponseBody();
        return TeaModel.build(map, self);
    }

    public DescribeDBProxyResponseBody setDBProxyAVZones(DescribeDBProxyResponseBodyDBProxyAVZones DBProxyAVZones) {
        this.DBProxyAVZones = DBProxyAVZones;
        return this;
    }
    public DescribeDBProxyResponseBodyDBProxyAVZones getDBProxyAVZones() {
        return this.DBProxyAVZones;
    }

    public DescribeDBProxyResponseBody setDBProxyConnectStringItems(DescribeDBProxyResponseBodyDBProxyConnectStringItems DBProxyConnectStringItems) {
        this.DBProxyConnectStringItems = DBProxyConnectStringItems;
        return this;
    }
    public DescribeDBProxyResponseBodyDBProxyConnectStringItems getDBProxyConnectStringItems() {
        return this.DBProxyConnectStringItems;
    }

    public DescribeDBProxyResponseBody setDBProxyEngineType(String DBProxyEngineType) {
        this.DBProxyEngineType = DBProxyEngineType;
        return this;
    }
    public String getDBProxyEngineType() {
        return this.DBProxyEngineType;
    }

    public DescribeDBProxyResponseBody setDBProxyInstanceCurrentMinorVersion(String DBProxyInstanceCurrentMinorVersion) {
        this.DBProxyInstanceCurrentMinorVersion = DBProxyInstanceCurrentMinorVersion;
        return this;
    }
    public String getDBProxyInstanceCurrentMinorVersion() {
        return this.DBProxyInstanceCurrentMinorVersion;
    }

    public DescribeDBProxyResponseBody setDBProxyInstanceLatestMinorVersion(String DBProxyInstanceLatestMinorVersion) {
        this.DBProxyInstanceLatestMinorVersion = DBProxyInstanceLatestMinorVersion;
        return this;
    }
    public String getDBProxyInstanceLatestMinorVersion() {
        return this.DBProxyInstanceLatestMinorVersion;
    }

    public DescribeDBProxyResponseBody setDBProxyInstanceMinorVersions(DescribeDBProxyResponseBodyDBProxyInstanceMinorVersions DBProxyInstanceMinorVersions) {
        this.DBProxyInstanceMinorVersions = DBProxyInstanceMinorVersions;
        return this;
    }
    public DescribeDBProxyResponseBodyDBProxyInstanceMinorVersions getDBProxyInstanceMinorVersions() {
        return this.DBProxyInstanceMinorVersions;
    }

    public DescribeDBProxyResponseBody setDBProxyInstanceName(String DBProxyInstanceName) {
        this.DBProxyInstanceName = DBProxyInstanceName;
        return this;
    }
    public String getDBProxyInstanceName() {
        return this.DBProxyInstanceName;
    }

    public DescribeDBProxyResponseBody setDBProxyInstanceNum(Integer DBProxyInstanceNum) {
        this.DBProxyInstanceNum = DBProxyInstanceNum;
        return this;
    }
    public Integer getDBProxyInstanceNum() {
        return this.DBProxyInstanceNum;
    }

    public DescribeDBProxyResponseBody setDBProxyInstanceSize(String DBProxyInstanceSize) {
        this.DBProxyInstanceSize = DBProxyInstanceSize;
        return this;
    }
    public String getDBProxyInstanceSize() {
        return this.DBProxyInstanceSize;
    }

    public DescribeDBProxyResponseBody setDBProxyInstanceStatus(String DBProxyInstanceStatus) {
        this.DBProxyInstanceStatus = DBProxyInstanceStatus;
        return this;
    }
    public String getDBProxyInstanceStatus() {
        return this.DBProxyInstanceStatus;
    }

    public DescribeDBProxyResponseBody setDBProxyInstanceType(String DBProxyInstanceType) {
        this.DBProxyInstanceType = DBProxyInstanceType;
        return this;
    }
    public String getDBProxyInstanceType() {
        return this.DBProxyInstanceType;
    }

    public DescribeDBProxyResponseBody setDBProxyKindCode(String DBProxyKindCode) {
        this.DBProxyKindCode = DBProxyKindCode;
        return this;
    }
    public String getDBProxyKindCode() {
        return this.DBProxyKindCode;
    }

    public DescribeDBProxyResponseBody setDBProxyNodes(DescribeDBProxyResponseBodyDBProxyNodes DBProxyNodes) {
        this.DBProxyNodes = DBProxyNodes;
        return this;
    }
    public DescribeDBProxyResponseBodyDBProxyNodes getDBProxyNodes() {
        return this.DBProxyNodes;
    }

    public DescribeDBProxyResponseBody setDBProxyPersistentConnectionStatus(String DBProxyPersistentConnectionStatus) {
        this.DBProxyPersistentConnectionStatus = DBProxyPersistentConnectionStatus;
        return this;
    }
    public String getDBProxyPersistentConnectionStatus() {
        return this.DBProxyPersistentConnectionStatus;
    }

    public DescribeDBProxyResponseBody setDBProxyServiceStatus(String DBProxyServiceStatus) {
        this.DBProxyServiceStatus = DBProxyServiceStatus;
        return this;
    }
    public String getDBProxyServiceStatus() {
        return this.DBProxyServiceStatus;
    }

    public DescribeDBProxyResponseBody setDbProxyEndpointItems(DescribeDBProxyResponseBodyDbProxyEndpointItems dbProxyEndpointItems) {
        this.dbProxyEndpointItems = dbProxyEndpointItems;
        return this;
    }
    public DescribeDBProxyResponseBodyDbProxyEndpointItems getDbProxyEndpointItems() {
        return this.dbProxyEndpointItems;
    }

    public DescribeDBProxyResponseBody setRequestId(String requestId) {
        this.requestId = requestId;
        return this;
    }
    public String getRequestId() {
        return this.requestId;
    }

    public DescribeDBProxyResponseBody setResourceGroupId(String resourceGroupId) {
        this.resourceGroupId = resourceGroupId;
        return this;
    }
    public String getResourceGroupId() {
        return this.resourceGroupId;
    }

    public static class DescribeDBProxyResponseBodyDBProxyAVZones extends TeaModel {
        @NameInMap("DBProxyAVZones")
        public java.util.List<String> DBProxyAVZones;

        public static DescribeDBProxyResponseBodyDBProxyAVZones build(java.util.Map<String, ?> map) throws Exception {
            DescribeDBProxyResponseBodyDBProxyAVZones self = new DescribeDBProxyResponseBodyDBProxyAVZones();
            return TeaModel.build(map, self);
        }

        public DescribeDBProxyResponseBodyDBProxyAVZones setDBProxyAVZones(java.util.List<String> DBProxyAVZones) {
            this.DBProxyAVZones = DBProxyAVZones;
            return this;
        }
        public java.util.List<String> getDBProxyAVZones() {
            return this.DBProxyAVZones;
        }

    }

    public static class DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems extends TeaModel {
        @NameInMap("DBProxyConnectString")
        public String DBProxyConnectString;

        @NameInMap("DBProxyConnectStringNetType")
        public String DBProxyConnectStringNetType;

        @NameInMap("DBProxyConnectStringNetWorkType")
        public String DBProxyConnectStringNetWorkType;

        @NameInMap("DBProxyConnectStringPort")
        public String DBProxyConnectStringPort;

        @NameInMap("DBProxyEndpointId")
        public String DBProxyEndpointId;

        @NameInMap("DBProxyEndpointName")
        public String DBProxyEndpointName;

        @NameInMap("DBProxyVpcId")
        public String DBProxyVpcId;

        @NameInMap("DBProxyVpcInstanceId")
        public String DBProxyVpcInstanceId;

        @NameInMap("DBProxyVswitchId")
        public String DBProxyVswitchId;

        public static DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems build(java.util.Map<String, ?> map) throws Exception {
            DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems self = new DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems();
            return TeaModel.build(map, self);
        }

        public DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems setDBProxyConnectString(String DBProxyConnectString) {
            this.DBProxyConnectString = DBProxyConnectString;
            return this;
        }
        public String getDBProxyConnectString() {
            return this.DBProxyConnectString;
        }

        public DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems setDBProxyConnectStringNetType(String DBProxyConnectStringNetType) {
            this.DBProxyConnectStringNetType = DBProxyConnectStringNetType;
            return this;
        }
        public String getDBProxyConnectStringNetType() {
            return this.DBProxyConnectStringNetType;
        }

        public DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems setDBProxyConnectStringNetWorkType(String DBProxyConnectStringNetWorkType) {
            this.DBProxyConnectStringNetWorkType = DBProxyConnectStringNetWorkType;
            return this;
        }
        public String getDBProxyConnectStringNetWorkType() {
            return this.DBProxyConnectStringNetWorkType;
        }

        public DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems setDBProxyConnectStringPort(String DBProxyConnectStringPort) {
            this.DBProxyConnectStringPort = DBProxyConnectStringPort;
            return this;
        }
        public String getDBProxyConnectStringPort() {
            return this.DBProxyConnectStringPort;
        }

        public DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems setDBProxyEndpointId(String DBProxyEndpointId) {
            this.DBProxyEndpointId = DBProxyEndpointId;
            return this;
        }
        public String getDBProxyEndpointId() {
            return this.DBProxyEndpointId;
        }

        public DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems setDBProxyEndpointName(String DBProxyEndpointName) {
            this.DBProxyEndpointName = DBProxyEndpointName;
            return this;
        }
        public String getDBProxyEndpointName() {
            return this.DBProxyEndpointName;
        }

        public DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems setDBProxyVpcId(String DBProxyVpcId) {
            this.DBProxyVpcId = DBProxyVpcId;
            return this;
        }
        public String getDBProxyVpcId() {
            return this.DBProxyVpcId;
        }

        public DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems setDBProxyVpcInstanceId(String DBProxyVpcInstanceId) {
            this.DBProxyVpcInstanceId = DBProxyVpcInstanceId;
            return this;
        }
        public String getDBProxyVpcInstanceId() {
            return this.DBProxyVpcInstanceId;
        }

        public DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems setDBProxyVswitchId(String DBProxyVswitchId) {
            this.DBProxyVswitchId = DBProxyVswitchId;
            return this;
        }
        public String getDBProxyVswitchId() {
            return this.DBProxyVswitchId;
        }

    }

    public static class DescribeDBProxyResponseBodyDBProxyConnectStringItems extends TeaModel {
        @NameInMap("DBProxyConnectStringItems")
        public java.util.List<DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems> DBProxyConnectStringItems;

        public static DescribeDBProxyResponseBodyDBProxyConnectStringItems build(java.util.Map<String, ?> map) throws Exception {
            DescribeDBProxyResponseBodyDBProxyConnectStringItems self = new DescribeDBProxyResponseBodyDBProxyConnectStringItems();
            return TeaModel.build(map, self);
        }

        public DescribeDBProxyResponseBodyDBProxyConnectStringItems setDBProxyConnectStringItems(java.util.List<DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems> DBProxyConnectStringItems) {
            this.DBProxyConnectStringItems = DBProxyConnectStringItems;
            return this;
        }
        public java.util.List<DescribeDBProxyResponseBodyDBProxyConnectStringItemsDBProxyConnectStringItems> getDBProxyConnectStringItems() {
            return this.DBProxyConnectStringItems;
        }

    }

    public static class DescribeDBProxyResponseBodyDBProxyInstanceMinorVersions extends TeaModel {
        @NameInMap("DBProxyInstanceMinorVersions")
        public java.util.List<String> DBProxyInstanceMinorVersions;

        public static DescribeDBProxyResponseBodyDBProxyInstanceMinorVersions build(java.util.Map<String, ?> map) throws Exception {
            DescribeDBProxyResponseBodyDBProxyInstanceMinorVersions self = new DescribeDBProxyResponseBodyDBProxyInstanceMinorVersions();
            return TeaModel.build(map, self);
        }

        public DescribeDBProxyResponseBodyDBProxyInstanceMinorVersions setDBProxyInstanceMinorVersions(java.util.List<String> DBProxyInstanceMinorVersions) {
            this.DBProxyInstanceMinorVersions = DBProxyInstanceMinorVersions;
            return this;
        }
        public java.util.List<String> getDBProxyInstanceMinorVersions() {
            return this.DBProxyInstanceMinorVersions;
        }

    }

    public static class DescribeDBProxyResponseBodyDBProxyNodesDBProxyNodes extends TeaModel {
        @NameInMap("cpuCores")
        public String cpuCores;

        /**
         * <strong>example:</strong>
         * <p>pn-xxxxxxx01</p>
         */
        @NameInMap("nodeId")
        public String nodeId;

        @NameInMap("zoneId")
        public String zoneId;

        public static DescribeDBProxyResponseBodyDBProxyNodesDBProxyNodes build(java.util.Map<String, ?> map) throws Exception {
            DescribeDBProxyResponseBodyDBProxyNodesDBProxyNodes self = new DescribeDBProxyResponseBodyDBProxyNodesDBProxyNodes();
            return TeaModel.build(map, self);
        }

        public DescribeDBProxyResponseBodyDBProxyNodesDBProxyNodes setCpuCores(String cpuCores) {
            this.cpuCores = cpuCores;
            return this;
        }
        public String getCpuCores() {
            return this.cpuCores;
        }

        public DescribeDBProxyResponseBodyDBProxyNodesDBProxyNodes setNodeId(String nodeId) {
            this.nodeId = nodeId;
            return this;
        }
        public String getNodeId() {
            return this.nodeId;
        }

        public DescribeDBProxyResponseBodyDBProxyNodesDBProxyNodes setZoneId(String zoneId) {
            this.zoneId = zoneId;
            return this;
        }
        public String getZoneId() {
            return this.zoneId;
        }

    }

    public static class DescribeDBProxyResponseBodyDBProxyNodes extends TeaModel {
        @NameInMap("DBProxyNodes")
        public java.util.List<DescribeDBProxyResponseBodyDBProxyNodesDBProxyNodes> DBProxyNodes;

        public static DescribeDBProxyResponseBodyDBProxyNodes build(java.util.Map<String, ?> map) throws Exception {
            DescribeDBProxyResponseBodyDBProxyNodes self = new DescribeDBProxyResponseBodyDBProxyNodes();
            return TeaModel.build(map, self);
        }

        public DescribeDBProxyResponseBodyDBProxyNodes setDBProxyNodes(java.util.List<DescribeDBProxyResponseBodyDBProxyNodesDBProxyNodes> DBProxyNodes) {
            this.DBProxyNodes = DBProxyNodes;
            return this;
        }
        public java.util.List<DescribeDBProxyResponseBodyDBProxyNodesDBProxyNodes> getDBProxyNodes() {
            return this.DBProxyNodes;
        }

    }

    public static class DescribeDBProxyResponseBodyDbProxyEndpointItemsDbProxyEndpointItems extends TeaModel {
        @NameInMap("DbProxyEndpointAliases")
        public String dbProxyEndpointAliases;

        @NameInMap("DbProxyEndpointName")
        public String dbProxyEndpointName;

        @NameInMap("DbProxyEndpointType")
        public String dbProxyEndpointType;

        @NameInMap("DbProxyReadWriteMode")
        public String dbProxyReadWriteMode;

        public static DescribeDBProxyResponseBodyDbProxyEndpointItemsDbProxyEndpointItems build(java.util.Map<String, ?> map) throws Exception {
            DescribeDBProxyResponseBodyDbProxyEndpointItemsDbProxyEndpointItems self = new DescribeDBProxyResponseBodyDbProxyEndpointItemsDbProxyEndpointItems();
            return TeaModel.build(map, self);
        }

        public DescribeDBProxyResponseBodyDbProxyEndpointItemsDbProxyEndpointItems setDbProxyEndpointAliases(String dbProxyEndpointAliases) {
            this.dbProxyEndpointAliases = dbProxyEndpointAliases;
            return this;
        }
        public String getDbProxyEndpointAliases() {
            return this.dbProxyEndpointAliases;
        }

        public DescribeDBProxyResponseBodyDbProxyEndpointItemsDbProxyEndpointItems setDbProxyEndpointName(String dbProxyEndpointName) {
            this.dbProxyEndpointName = dbProxyEndpointName;
            return this;
        }
        public String getDbProxyEndpointName() {
            return this.dbProxyEndpointName;
        }

        public DescribeDBProxyResponseBodyDbProxyEndpointItemsDbProxyEndpointItems setDbProxyEndpointType(String dbProxyEndpointType) {
            this.dbProxyEndpointType = dbProxyEndpointType;
            return this;
        }
        public String getDbProxyEndpointType() {
            return this.dbProxyEndpointType;
        }

        public DescribeDBProxyResponseBodyDbProxyEndpointItemsDbProxyEndpointItems setDbProxyReadWriteMode(String dbProxyReadWriteMode) {
            this.dbProxyReadWriteMode = dbProxyReadWriteMode;
            return this;
        }
        public String getDbProxyReadWriteMode() {
            return this.dbProxyReadWriteMode;
        }

    }

    public static class DescribeDBProxyResponseBodyDbProxyEndpointItems extends TeaModel {
        @NameInMap("DbProxyEndpointItems")
        public java.util.List<DescribeDBProxyResponseBodyDbProxyEndpointItemsDbProxyEndpointItems> dbProxyEndpointItems;

        public static DescribeDBProxyResponseBodyDbProxyEndpointItems build(java.util.Map<String, ?> map) throws Exception {
            DescribeDBProxyResponseBodyDbProxyEndpointItems self = new DescribeDBProxyResponseBodyDbProxyEndpointItems();
            return TeaModel.build(map, self);
        }

        public DescribeDBProxyResponseBodyDbProxyEndpointItems setDbProxyEndpointItems(java.util.List<DescribeDBProxyResponseBodyDbProxyEndpointItemsDbProxyEndpointItems> dbProxyEndpointItems) {
            this.dbProxyEndpointItems = dbProxyEndpointItems;
            return this;
        }
        public java.util.List<DescribeDBProxyResponseBodyDbProxyEndpointItemsDbProxyEndpointItems> getDbProxyEndpointItems() {
            return this.dbProxyEndpointItems;
        }

    }

}
