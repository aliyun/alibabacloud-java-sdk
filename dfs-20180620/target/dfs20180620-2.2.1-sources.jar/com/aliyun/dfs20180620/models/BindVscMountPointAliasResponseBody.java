// This file is auto-generated, don't edit it. Thanks.
package com.aliyun.dfs20180620.models;

import com.aliyun.tea.*;

public class BindVscMountPointAliasResponseBody extends TeaModel {
    /**
     * <p>The mount point alias.</p>
     * 
     * <strong>example:</strong>
     * <p>sdfe</p>
     */
    @NameInMap("MountPointAlias")
    public String mountPointAlias;

    /**
     * <p>The request ID.</p>
     * 
     * <strong>example:</strong>
     * <p>55C5FFD6-BF99-41BD-9C66-FFF39189****</p>
     */
    @NameInMap("RequestId")
    public String requestId;

    public static BindVscMountPointAliasResponseBody build(java.util.Map<String, ?> map) throws Exception {
        BindVscMountPointAliasResponseBody self = new BindVscMountPointAliasResponseBody();
        return TeaModel.build(map, self);
    }

    public BindVscMountPointAliasResponseBody setMountPointAlias(String mountPointAlias) {
        this.mountPointAlias = mountPointAlias;
        return this;
    }
    public String getMountPointAlias() {
        return this.mountPointAlias;
    }

    public BindVscMountPointAliasResponseBody setRequestId(String requestId) {
        this.requestId = requestId;
        return this;
    }
    public String getRequestId() {
        return this.requestId;
    }

}
